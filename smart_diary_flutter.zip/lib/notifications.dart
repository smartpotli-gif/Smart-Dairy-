import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'l10n.dart';
import 'store.dart';
import 'util.dart';

class Notif {
  static final _p = FlutterLocalNotificationsPlugin();
  static bool _busy = false;
  static const _details = NotificationDetails(
    android: AndroidNotificationDetails('diary_reminders', 'Reminders',
        channelDescription: 'Smart Diary reminders', importance: Importance.high, priority: Priority.high),
  );

  static Future<void> init() async {
    tzdata.initializeTimeZones();
    try {
      tz.setLocalLocation(tz.getLocation('Asia/Kolkata'));
    } catch (_) {}
    await _p.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
    try {
      await _p.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
    } catch (_) {}
  }

  static Future<void> _at(int id, String title, String body, DateTime when) async {
    if (when.isBefore(DateTime.now())) return;
    try {
      await _p.zonedSchedule(id, title, body, tz.TZDateTime.from(when, tz.local), _details,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime);
    } catch (_) {}
  }

  static Future<void> _daily(int id, String title, String body, int hour) async {
    final now = tz.TZDateTime.now(tz.local);
    var w = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour);
    if (w.isBefore(now)) w = w.add(const Duration(days: 1));
    try {
      await _p.zonedSchedule(id, title, body, w, _details,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
          matchDateTimeComponents: DateTimeComponents.time);
    } catch (_) {}
  }

  static Future<void> rescheduleAll(Store st) async {
    if (_busy) return;
    _busy = true;
    try {
      try {
        await _p.cancelAll();
      } catch (_) {}
      final s = st.s;
      if (s.morningOn) {
        await _daily(1, t('🌅 सुप्रभात', '🌅 Good morning') + (s.name.isEmpty ? '' : ' ${s.name}'),
            t('आजच्या मीटिंग्स आणि कामं बघा.', "Check today's meetings and tasks."), s.morningHour);
      }
      if (s.eodOn) {
        await _daily(2, t('🌙 दिवसाचा शेवट', '🌙 End of day'),
            t('आजचा आढावा घ्या आणि नोंद सेव्ह करा.', "Review today and save your diary note."), s.eodHour);
      }
      var count = 0;
      final before = Duration(minutes: s.remindBefore);
      final now = DateTime.now();
      for (final e in sortItems(st.items.where((x) => x.timed && !x.done && !x.tpl).toList())) {
        final w = whenOf(e.date, e.time);
        if (w == null || w.isBefore(now)) continue;
        final icon = e.type == 'meeting' ? '🤝' : '⏰';
        final who = e.person.isNotEmpty ? ' · ${e.person}' : '';
        if (s.remindBefore > 0) {
          await _at(100000 + e.id * 2, '$icon ${t('${s.remindBefore} मिनिटांनी', 'In ${s.remindBefore} min')}: ${e.title}', '${e.time}$who',
              w.subtract(before));
        }
        await _at(100000 + e.id * 2 + 1, '$icon ${e.title}', '${t('आता वेळ झाली', 'Time now')} (${e.time})$who', w);
        if (++count > 50) break;
      }
      for (final tr in st.items.where((x) => x.type == 'trip' && !x.done)) {
        for (var i = 0; i < tr.trip.length && i < 20; i++) {
          final it = tr.trip[i];
          final w = whenOf(it.date, it.time);
          if (it.d || w == null) continue;
          await _at(5000000 + tr.id * 20 + i, '✈️ ${tr.title}: ${it.k}', '${it.detail} (${it.time})', w.subtract(const Duration(minutes: 60)));
        }
      }
    } finally {
      _busy = false;
    }
  }
}
