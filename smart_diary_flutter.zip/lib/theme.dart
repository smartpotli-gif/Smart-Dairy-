import 'package:flutter/material.dart';

/// Smart Potli brand: Cream #F8F5ED, Deep Green #173F35, Gold #C9A227.
class C {
  static const green = Color(0xFF173F35);
  static const green2 = Color(0xFF285C4D);
  static const gold = Color(0xFFC9A227);
  static const softGold = Color(0xFFE4D39A);
  static const cream = Color(0xFFF8F5ED);
  static const surface = Color(0xFFFFFDF8);
  static const red = Color(0xFFC0392B);
  static const wa = Color(0xFF1FAF5A);
  static const aiA = Color(0xFF6B4FD8);
  static const aiB = Color(0xFFC94F9B);
  // dark palette
  static const dBg = Color(0xFF0F1A16);
  static const dSurface = Color(0xFF18261F);
  static const dMint = Color(0xFF8FD1B8);
  static const dBorder = Color(0xFF2C3D35);
}

bool isDark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;
Color headColor(BuildContext c) => isDark(c) ? C.dMint : C.green;
Color hint(BuildContext c) => Theme.of(c).hintColor;
Color meetingBg(BuildContext c) => isDark(c) ? const Color(0xFF1C2B36) : const Color(0xFFE8EFF7);
Color tripBg(BuildContext c) => isDark(c) ? const Color(0xFF1F2D20) : const Color(0xFFEEF5EA);
Color redText(BuildContext c) => isDark(c) ? const Color(0xFFFF8A80) : C.red;

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final base = ColorScheme.fromSeed(seedColor: C.green, brightness: b);
  final scheme = dark
      ? base.copyWith(
          primary: C.dMint, onPrimary: const Color(0xFF0B241D), secondary: C.gold, onSecondary: Colors.black,
          surface: C.dSurface, onSurface: const Color(0xFFE8ECE9), primaryContainer: const Color(0xFF24443A),
          onPrimaryContainer: const Color(0xFFD5EFE5), outline: C.dBorder)
      : base.copyWith(
          primary: C.green, onPrimary: Colors.white, secondary: C.gold, onSecondary: Colors.black,
          surface: C.surface, onSurface: const Color(0xFF1C2824), primaryContainer: C.softGold,
          onPrimaryContainer: const Color(0xFF3A2F05), outline: const Color(0xFFE6E0D3));
  final bg = dark ? C.dBg : C.cream;
  final border = dark ? C.dBorder : const Color(0xFFE6E0D3);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    fontFamily: 'Poppins',
    scaffoldBackgroundColor: bg,
    hintColor: dark ? const Color(0xFF9AA8A1) : const Color(0xFF7D8783),
    dividerColor: border,
    appBarTheme: AppBarTheme(backgroundColor: bg, foregroundColor: scheme.onSurface, elevation: 0, scrolledUnderElevation: 0),
    cardTheme: CardTheme(
      color: scheme.surface,
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: border)),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: scheme.surface,
      isDense: true,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: border)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: C.gold, width: 1.6)),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
          backgroundColor: scheme.primary, foregroundColor: scheme.onPrimary,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)), padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12)),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(foregroundColor: scheme.primary, side: BorderSide(color: border), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
    ),
    textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(foregroundColor: scheme.primary)),
    checkboxTheme: CheckboxThemeData(
      fillColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? scheme.primary : null),
      checkColor: WidgetStateProperty.all(scheme.onPrimary),
      side: BorderSide(color: scheme.primary, width: 2),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: scheme.surface,
      selectedColor: dark ? const Color(0xFF3A3215) : C.softGold,
      labelStyle: TextStyle(color: scheme.onSurface, fontSize: 13),
      side: BorderSide(color: border),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(backgroundColor: scheme.primary, foregroundColor: scheme.onPrimary),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: scheme.surface,
      indicatorColor: dark ? const Color(0xFF3A3215) : C.softGold,
      labelTextStyle: WidgetStateProperty.all(TextStyle(fontSize: 11, color: scheme.onSurface)),
      iconTheme: WidgetStateProperty.all(IconThemeData(color: scheme.onSurface)),
    ),
    snackBarTheme: SnackBarThemeData(
        backgroundColor: dark ? const Color(0xFF24443A) : C.green, contentTextStyle: const TextStyle(color: Colors.white), actionTextColor: C.gold),
    bottomSheetTheme: BottomSheetThemeData(backgroundColor: bg),
    dialogTheme: DialogTheme(backgroundColor: scheme.surface),
  );
}
