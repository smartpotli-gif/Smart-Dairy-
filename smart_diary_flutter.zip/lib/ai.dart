import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'l10n.dart';
import 'store.dart';
import 'util.dart';

class AiError implements Exception {
  final String msg;
  AiError(this.msg);
  @override
  String toString() => msg;
}

class AI {
  static bool get ready => Store.I.s.aiOn && Store.I.s.aiKey.trim().isNotEmpty;

  static Future<String> ask(String prompt, {bool json = false}) async {
    final s = Store.I.s;
    if (!ready) throw AiError(t('AI साठी Settings मध्ये मोफत Gemini key टाका.', 'Add your free Gemini key in Settings to use AI.'));
    final uri = Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/${s.aiModel.trim()}:generateContent');
    final body = <String, dynamic>{
      'contents': [
        {
          'role': 'user',
          'parts': [
            {'text': prompt}
          ]
        }
      ],
    };
    if (json) body['generationConfig'] = {'responseMimeType': 'application/json'};
    http.Response r;
    try {
      r = await http
          .post(uri, headers: {'Content-Type': 'application/json', 'x-goog-api-key': s.aiKey.trim()}, body: jsonEncode(body))
          .timeout(const Duration(seconds: 60));
    } on SocketException {
      throw AiError(t('इंटरनेट नाही. AI साठी नेट चालू करा (बाकी अॅप ऑफलाइन चालतं).', 'No internet. Turn on data for AI (the rest of the app works offline).'));
    } on TimeoutException {
      throw AiError(t('AI ला उत्तर द्यायला वेळ लागला. परत प्रयत्न करा.', 'AI took too long. Please try again.'));
    }
    if (r.statusCode == 429) throw AiError(t('मोफत AI लिमिट संपली किंवा खूप जलद विचारलं. थोड्या वेळाने प्रयत्न करा.', 'Free AI limit reached or too many requests. Try again later.'));
    if (r.statusCode == 400 || r.statusCode == 401 || r.statusCode == 403) {
      throw AiError(t('AI key चुकीची वाटते. Settings मध्ये key तपासा.', 'The AI key looks wrong. Check it in Settings.'));
    }
    if (r.statusCode == 404) throw AiError(t('AI मॉडेल सापडलं नाही. Settings मध्ये मॉडेल नाव तपासा.', 'AI model not found. Check the model name in Settings.'));
    if (r.statusCode != 200) throw AiError(t('AI चाललं नाही (${r.statusCode}). परत प्रयत्न करा.', 'AI failed (${r.statusCode}). Please try again.'));
    final j = jsonDecode(utf8.decode(r.bodyBytes));
    final cands = j['candidates'];
    if (cands is! List || cands.isEmpty) throw AiError(t('AI ने उत्तर दिलं नाही. वेगळ्या शब्दांत विचारा.', 'AI gave no answer. Try different words.'));
    final parts = (cands[0]['content']?['parts'] as List?) ?? [];
    return parts.map((p) => (p['text'] ?? '').toString()).join().trim();
  }

  static Future<dynamic> askJson(String prompt) async {
    var raw = await ask(prompt, json: true);
    raw = raw.replaceAll(RegExp(r'```(json)?'), '').trim();
    return jsonDecode(raw);
  }

  static String lang() => langFor(Store.I.s.aiLang);

  static String langFor(String code) {
    switch (code) {
      case 'en':
        return 'in professional English';
      case 'both':
        return 'first in Marathi, then in English below';
      default:
        return 'in Marathi (मराठीत)';
    }
  }

  static String context() {
    final all = Store.I.live;
    final l = all.length > 80 ? all.sublist(all.length - 80) : all;
    return l.map((e) {
      if (e.isNote) return '[नोट ${e.date}${e.title.isNotEmpty ? ' विषय: ${e.title}' : ''}${e.person.isNotEmpty ? ' ${e.person}' : ''}] ${e.content}';
      if (e.type == 'trip') {
        return '[ट्रिप ${e.date}] ${e.title}: ${e.trip.map((i) => '${i.k} ${i.detail}${i.d ? ' ✔' : ''}').join('; ')}';
      }
      final pts = e.points.isEmpty ? '' : ' | ${e.points.map((p) => p.t + (p.d ? ' ✔' : '')).join('; ')}';
      return '[${e.type == 'meeting' ? 'मीटिंग' : 'टास्क'} ${e.date} ${e.time ?? ''}] ${e.title}'
          '${e.person.isNotEmpty ? ' (सोबत ${e.person})' : ''}${e.done ? ' ✔' : ''}$pts';
    }).join('\n');
  }

  static String clean(String text) => Store.I.s.maskOn ? maskSensitive(text) : text;

  static String header() => 'तू माझ्या business डायरी अॅपमधला मदतनीस आहेस. आज ${todayKey()}, वेळ ${nowHM()}. '
      'Markdown (*, #) वापरू नको; थेट copy करून पाठवता येईल असा साधा मजकूर दे.';
}
