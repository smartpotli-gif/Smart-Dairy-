import 'store.dart';

bool get isEn => Store.I.s.lang == 'en';

/// Every visible text goes through this: t('मराठी', 'English').
String t(String mr, String en) => isEn ? en : mr;

String get loc => isEn ? 'en' : 'mr';

const weekdayMr = ['सोम', 'मंगळ', 'बुध', 'गुरु', 'शुक्र', 'शनि', 'रवि'];
const weekdayEn = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
String wd(int weekday) => (isEn ? weekdayEn : weekdayMr)[weekday - 1];
