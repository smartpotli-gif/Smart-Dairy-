import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'models.dart';
import 'notifications.dart';
import 'util.dart';

class Store extends ChangeNotifier {
  static final Store I = Store._();
  Store._();

  List<Item> items = [];
  List<Contact> contacts = [];
  Settings s = Settings();
  int nextId = 1;
  File? _file;
  Timer? _writeT, _notifT;

  /// Bumped when theme / language changes (only then the whole app rebuilds).
  final ui = ValueNotifier<int>(0);

  /// Items just ticked: kept visible ~1.2 s so the tick is seen before they move.
  final Set<int> justToggled = {};

  /// Visible items (templates of repeating items are hidden).
  List<Item> get live => items.where((e) => !e.tpl).toList();
  List<Item> get notes => items.where((e) => e.isNote).toList();
  List<Item> timedOn(String day) => sortItems(items.where((e) => !e.tpl && e.timed && e.date == day).toList());

  Future<void> load() async {
    final dir = await getApplicationDocumentsDirectory();
    _file = File('${dir.path}/smart_diary.json');
    if (await _file!.exists()) {
      try {
        _apply(jsonDecode(await _file!.readAsString()) as Map<String, dynamic>, withSettings: true);
      } catch (_) {}
    }
    materialize();
  }

  void _apply(Map<String, dynamic> j, {required bool withSettings}) {
    items = ((j['items'] as List?) ?? []).map((e) => Item.fromJson(Map<String, dynamic>.from(e))).toList();
    contacts = ((j['contacts'] as List?) ?? []).map((e) => Contact.fromJson(Map<String, dynamic>.from(e))).toList();
    nextId = j['nextId'] ?? 1;
    for (final e in items) {
      if (e.id >= nextId) nextId = e.id + 1;
    }
    if (withSettings && j['settings'] != null) s = Settings.fromJson(Map<String, dynamic>.from(j['settings']));
  }

  Map<String, dynamic> toJson({bool forBackup = false}) {
    final st = s.toJson();
    if (forBackup) {
      st.remove('pin');
      st.remove('aiKey');
    }
    return {
      'app': 'smart_diary', 'v': 2, 'at': DateTime.now().toIso8601String(), 'nextId': nextId,
      'items': items.map((e) => e.toJson()).toList(),
      'contacts': contacts.map((e) => e.toJson()).toList(),
      'settings': st,
    };
  }

  String backupJson() => jsonEncode(toJson(forBackup: true));

  Future<bool> restore(String text) async {
    try {
      final j = jsonDecode(text) as Map<String, dynamic>;
      if (j['app'] != 'smart_diary' || j['items'] is! List) return false;
      _apply(j, withSettings: false);
      materialize();
      save();
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Fast: UI updates immediately; file write and reminders happen shortly after, in background.
  void save({bool reschedule = true}) {
    notifyListeners();
    _writeT?.cancel();
    _writeT = Timer(const Duration(milliseconds: 400), flush);
    if (reschedule) {
      _notifT?.cancel();
      _notifT = Timer(const Duration(seconds: 2), () => Notif.rescheduleAll(this));
    }
  }

  Future<void> flush() async {
    _writeT?.cancel();
    try {
      await _file?.writeAsString(jsonEncode(toJson()));
    } catch (_) {}
  }

  /// Theme / language change.
  void uiChanged() {
    ui.value++;
    save();
  }

  int newId() => nextId++;

  Item? byId(int id) {
    for (final e in items) {
      if (e.id == id) return e;
    }
    return null;
  }

  void add(Item e) {
    items.add(e);
    if (e.type == 'meeting') upsertContact(e.person, e.phone);
    if (e.tpl) materialize();
    save();
  }

  void remove(int id) {
    items.removeWhere((e) => e.id == id);
    save();
  }

  void wipe() {
    items = [];
    contacts = [];
    save();
  }

  void toggleDone(Item e) {
    e.done = !e.done;
    if (e.done) {
      justToggled.add(e.id);
      Timer(const Duration(milliseconds: 1200), () {
        justToggled.remove(e.id);
        notifyListeners();
      });
    }
    save();
  }

  /// Create real occurrences of repeating templates for the next 30 days.
  void materialize() {
    final today = DateTime.now();
    final from = DateTime(today.year, today.month, today.day);
    final until = from.add(const Duration(days: 30));
    final have = <String>{for (final e in items) if (e.parent != 0) '${e.parent}|${e.date}'};
    final add = <Item>[];
    for (final tp in items.where((e) => e.tpl && e.repeat.isNotEmpty)) {
      final start = parseKey(tp.date);
      if (start == null) continue;
      var n = 0;
      for (var d = start; !d.isAfter(until); d = DateTime(d.year, d.month, d.day + 1)) {
        if (!repeatMatches(tp, d)) continue;
        n++;
        if (tp.repeatCount > 0 && n > tp.repeatCount) break;
        if (d.isBefore(from)) continue;
        final k = dkey(d);
        if (tp.skips.contains(k) || have.contains('${tp.id}|$k')) continue;
        add.add(Item(
          id: nextId++, type: tp.type, title: tp.title, date: k, time: tp.time, person: tp.person, phone: tp.phone,
          priority: tp.priority, series: tp.id, parent: tp.id,
        ));
        have.add('${tp.id}|$k');
      }
    }
    if (add.isNotEmpty) items.addAll(add);
  }

  void upsertContact(String name, String phone) {
    name = name.trim();
    if (name.isEmpty) return;
    for (final c in contacts) {
      if (c.name == name) {
        if (phone.trim().isNotEmpty) c.phone = phone.trim();
        return;
      }
    }
    contacts.add(Contact(name: name, phone: phone.trim()));
  }

  Contact? contact(String name) {
    for (final c in contacts) {
      if (c.name == name) return c;
    }
    return null;
  }

  /// Distinct note subjects, most used first.
  List<String> get subjects {
    final m = <String, int>{};
    for (final e in notes) {
      if (e.title.trim().isNotEmpty && e.kind != 'eod') m[e.title.trim()] = (m[e.title.trim()] ?? 0) + 1;
    }
    final l = m.keys.toList()..sort((a, b) => m[b]!.compareTo(m[a]!));
    return l;
  }
}
