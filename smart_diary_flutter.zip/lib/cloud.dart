import 'dart:async';
import 'dart:convert';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import 'l10n.dart';
import 'store.dart';

/// Google Drive sync: one JSON backup in the app's hidden Drive folder (appDataFolder).
class Cloud {
  static const _name = 'smart_diary_backup.json';
  static final _gs = GoogleSignIn(scopes: ['https://www.googleapis.com/auth/drive.appdata']);
  static GoogleSignInAccount? user;
  static bool busy = false, applying = false, _pending = false;
  static String lastError = '';
  static Timer? _t;

  static bool get signedIn => user != null;

  static Future<void> init() async {
    try {
      user = await _gs.signInSilently();
    } catch (_) {}
  }

  static String _explain(Object e) {
    final s = e.toString();
    if (s.contains('ApiException: 10') || s.contains('DEVELOPER_ERROR')) {
      return t('Google ने अॅप ओळखलं नाही. Package नाव / SHA-1 तपासा, किंवा सेटिंग लागू व्हायला थोडा वेळ थांबा.',
          'Google did not recognise the app. Check package name / SHA-1, or wait a while for settings to apply.');
    }
    if (s.contains('access_denied') || s.contains('12500') || s.contains('403')) {
      return t('हा Gmail "Test users" मध्ये नाही. Google Cloud → Audience → Test users मध्ये जोडा.',
          'This Gmail is not in "Test users". Add it in Google Cloud → Audience → Test users.');
    }
    if (s.contains('network') || s.contains('SocketException') || s.contains('7:')) {
      return t('इंटरनेट नाही. नेट आल्यावर परत प्रयत्न करा.', 'No internet. Try again when online.');
    }
    return t('Google Drive शी जोडता आलं नाही.', 'Could not connect to Google Drive.');
  }

  static Future<bool> signIn() async {
    try {
      user = await _gs.signIn();
      if (user == null) return false;
      Store.I.s.cloudEmail = user!.email;
      _quietSave();
      return true;
    } catch (e) {
      lastError = _explain(e);
      return false;
    }
  }

  static Future<void> signOut() async {
    try {
      await _gs.signOut();
    } catch (_) {}
    user = null;
    Store.I.s.cloudEmail = '';
    _quietSave();
  }

  static void _quietSave() {
    applying = true;
    Store.I.save(reschedule: false);
    applying = false;
  }

  static Future<Map<String, String>> _headers() async {
    final u = user ?? await _gs.signInSilently();
    if (u == null) throw Exception('not signed in');
    user = u;
    return await u.authHeaders;
  }

  /// Returns (id, modifiedTime) of the backup file, or null.
  static Future<List<String>?> remoteInfo() async {
    final h = await _headers();
    final q = Uri.encodeQueryComponent("name='$_name'");
    final r = await http
        .get(Uri.parse('https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=$q&fields=files(id,modifiedTime)'), headers: h)
        .timeout(const Duration(seconds: 30));
    if (r.statusCode != 200) throw Exception('drive ${r.statusCode}');
    final files = (jsonDecode(r.body)['files'] as List?) ?? [];
    if (files.isEmpty) return null;
    return [files.first['id'].toString(), (files.first['modifiedTime'] ?? '').toString()];
  }

  /// Upload current data. Returns true on success.
  static Future<bool> upload() async {
    if (!signedIn || busy) return false;
    busy = true;
    _pending = false;
    try {
      await Store.I.flush();
      final data = Store.I.backupJson();
      final h = await _headers();
      final info = await remoteInfo();
      http.Response r;
      if (info == null) {
        const b = 'smartdiaryboundary';
        final body = '--$b\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n'
            '${jsonEncode({'name': _name, 'parents': ['appDataFolder']})}\r\n'
            '--$b\r\nContent-Type: application/json\r\n\r\n$data\r\n--$b--';
        r = await http
            .post(Uri.parse('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart'),
                headers: {...h, 'Content-Type': 'multipart/related; boundary=$b'}, body: utf8.encode(body))
            .timeout(const Duration(seconds: 60));
      } else {
        r = await http
            .patch(Uri.parse('https://www.googleapis.com/upload/drive/v3/files/${info[0]}?uploadType=media'),
                headers: {...h, 'Content-Type': 'application/json'}, body: utf8.encode(data))
            .timeout(const Duration(seconds: 60));
      }
      if (r.statusCode != 200) throw Exception('drive ${r.statusCode}');
      Store.I.s.lastSync = DateTime.now().toIso8601String();
      lastError = '';
      _quietSave();
      return true;
    } catch (e) {
      lastError = _explain(e);
      _pending = true;
      return false;
    } finally {
      busy = false;
    }
  }

  /// Download backup text from Drive, or null if none.
  static Future<String?> download() async {
    final info = await remoteInfo();
    if (info == null) return null;
    final h = await _headers();
    final r = await http.get(Uri.parse('https://www.googleapis.com/drive/v3/files/${info[0]}?alt=media'), headers: h).timeout(const Duration(seconds: 60));
    if (r.statusCode != 200) throw Exception('drive ${r.statusCode}');
    return utf8.decode(r.bodyBytes);
  }

  /// Called after every change: upload ~1 minute later (batched).
  static void schedule() {
    if (!signedIn || !Store.I.s.cloudOn) return;
    _pending = true;
    _t?.cancel();
    _t = Timer(const Duration(seconds: 60), upload);
  }

  /// When the app goes to background, upload right away if something is waiting.
  static void flushPending() {
    if (_pending && signedIn && Store.I.s.cloudOn) {
      _t?.cancel();
      upload();
    }
  }
}
