import 'package:flutter/material.dart';
import '../l10n.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../util.dart';
import '../widgets.dart';

class TripFormPage extends StatefulWidget {
  const TripFormPage({super.key});
  @override
  State<TripFormPage> createState() => _TripFormPageState();
}

class _TripFormPageState extends State<TripFormPage> {
  final title = TextEditingController();
  String date = daysFrom(7);
  bool useTpl = true;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('✈️ नवीन ट्रिप', '✈️ New trip'))),
        body: ListView(padding: const EdgeInsets.all(18), children: [
          TextField(controller: title, autofocus: true, decoration: InputDecoration(labelText: t('ट्रिपचं नाव', 'Trip name'), hintText: t('उदा. Delhi ट्रिप', 'e.g. Delhi trip'))),
          const SizedBox(height: 12),
          OutlinedButton.icon(
              onPressed: () async {
                final d = await pickDate(context, date);
                if (d != null) setState(() => date = d);
              },
              icon: const Icon(Icons.event),
              label: Text('${t('प्रवासाची तारीख', 'Travel date')}: ${nice(date)}')),
          SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: useTpl,
              onChanged: (v) => setState(() => useTpl = v),
              title: Text(t('फ्लाइट, हॉटेल, कॅब, व्हिसा, Insurance यादी आपोआप टाका', 'Add flight, hotel, cab, visa, insurance list'))),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: () {
              if (title.text.trim().isEmpty) {
                toast(context, t('नाव टाका', 'Enter a name'));
                return;
              }
              final st = Store.I;
              final tr = Item(
                  id: st.newId(), type: 'trip', title: title.text.trim(), date: date,
                  trip: useTpl ? tripTemplate.map((k) => TripItem(k: k, date: date)).toList() : []);
              st.add(tr);
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => TripPage(id: tr.id)));
            },
            child: Text(t('सेव्ह करा', 'Save')),
          ),
        ]),
      );
}

class TripPage extends StatelessWidget {
  final int id;
  const TripPage({super.key, required this.id});

  Future<void> editItem(BuildContext context, Item tr, int? i) async {
    final it = i == null ? TripItem(k: '', date: tr.date) : tr.trip[i];
    final k = TextEditingController(text: it.k), detail = TextEditingController(text: it.detail);
    String date = it.date, time = it.time;
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => Padding(
          padding: EdgeInsets.fromLTRB(18, 0, 18, MediaQuery.of(c).viewInsets.bottom + 18),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: k, decoration: InputDecoration(labelText: t('प्रकार (उदा. ✈️ फ्लाइट)', 'Type (e.g. ✈️ Flight)'))),
            const SizedBox(height: 10),
            TextField(controller: detail, decoration: InputDecoration(labelText: t('तपशील (PNR, हॉटेल, vendor…)', 'Details (PNR, hotel, vendor…)'))),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(
                  child: OutlinedButton(
                      onPressed: () async {
                        final d = await pickDate(c, date);
                        if (d != null) set(() => date = d);
                      },
                      child: Text(nice(date)))),
              const SizedBox(width: 8),
              Expanded(
                  child: OutlinedButton(
                      onPressed: () async {
                        final x = await pickTime(c, time.isEmpty ? null : time);
                        if (x != null) set(() => time = x);
                      },
                      child: Text(time.isEmpty ? t('वेळ', 'Time') : time))),
            ]),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () {
                  if (k.text.trim().isEmpty) return;
                  it
                    ..k = k.text.trim()
                    ..detail = detail.text.trim()
                    ..date = date
                    ..time = time;
                  if (i == null) tr.trip.add(it);
                  Store.I.save();
                  Navigator.pop(c);
                },
                child: Text(t('सेव्ह', 'Save')),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) {
          final st = Store.I;
          final tr = st.byId(id);
          if (tr == null) return Scaffold(appBar: AppBar(), body: Center(child: Text(t('ही ट्रिप डिलीट झाली.', 'This trip was deleted.'))));
          String summary() =>
              '${tr.title} — ${nice(tr.date)}\n${tr.trip.map((i) => '${i.d ? '✅' : '⏳'} ${i.k}${i.detail.isNotEmpty ? ': ${i.detail}' : ''}${i.time.isNotEmpty ? ' (${nice(i.date)} ${i.time})' : ''}').join('\n')}';
          return Scaffold(
            appBar: AppBar(title: Text('✈️ ${tr.title}'), actions: [
              IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    if (await deleteItem(context, tr) && context.mounted) Navigator.pop(context);
                  }),
            ]),
            floatingActionButton: FloatingActionButton.extended(onPressed: () => editItem(context, tr, null), icon: const Icon(Icons.add), label: Text(t('बुकिंग', 'Booking'))),
            body: ListView(padding: const EdgeInsets.fromLTRB(18, 0, 18, 90), children: [
              Text(nice(tr.date), style: TextStyle(color: hint(context))),
              Section(t('बुकिंग्स', 'Bookings')),
              if (tr.trip.isEmpty) Empty(t('खाली + बुकिंग दाबा.', 'Tap + Booking below.')),
              for (var i = 0; i < tr.trip.length; i++)
                Card(
                  child: ListTile(
                    leading: Checkbox(
                        value: tr.trip[i].d,
                        onChanged: (_) {
                          tr.trip[i].d = !tr.trip[i].d;
                          st.save();
                        }),
                    title: Text(tr.trip[i].k, style: TextStyle(decoration: tr.trip[i].d ? TextDecoration.lineThrough : null)),
                    subtitle: Text([
                      if (tr.trip[i].detail.isNotEmpty) tr.trip[i].detail,
                      if (tr.trip[i].time.isNotEmpty) '${nice(tr.trip[i].date)} · ${tr.trip[i].time} (${t('1 तास आधी रिमाइंडर', 'reminder 1 h before')})',
                    ].join('\n')),
                    onTap: () => editItem(context, tr, i),
                    trailing: IconButton(
                        icon: const Icon(Icons.close, size: 18),
                        onPressed: () {
                          tr.trip.removeAt(i);
                          st.save();
                        }),
                  ),
                ),
              Section(t('📤 शेअर', '📤 Share')),
              ShareBar(text: summary, subject: tr.title),
              const SizedBox(height: 12),
              OutlinedButton(
                  onPressed: () {
                    tr.done = !tr.done;
                    st.save();
                  },
                  child: Text(tr.done ? t('↺ परत उघडा', '↺ Reopen') : t('✔ ट्रिप पूर्ण', '✔ Trip complete'))),
            ]),
          );
        },
      );
}

class TripsPage extends StatelessWidget {
  const TripsPage({super.key});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) {
          final l = sortItems(Store.I.items.where((e) => e.type == 'trip').toList()).reversed.toList();
          return Scaffold(
            appBar: AppBar(title: Text(t('✈️ ट्रिप्स', '✈️ Trips'))),
            floatingActionButton: FloatingActionButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TripFormPage())), child: const Icon(Icons.add)),
            body: ListView(padding: const EdgeInsets.all(18), children: [
              if (l.isEmpty) Empty(t('अजून ट्रिप नाही.', 'No trips yet.')),
              ...l.map((e) => ItemTile(e)),
            ]),
          );
        },
      );
}
