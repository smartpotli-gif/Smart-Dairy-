import 'package:flutter/material.dart';
import '../l10n.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../util.dart';
import '../widgets.dart';

/// Add / edit a task or meeting, with repeat options.
class ItemFormPage extends StatefulWidget {
  final String type;
  final Item? edit;
  final String? date;
  const ItemFormPage({super.key, required this.type, this.edit, this.date});
  @override
  State<ItemFormPage> createState() => _ItemFormPageState();
}

class _ItemFormPageState extends State<ItemFormPage> {
  late final Item? tp = widget.edit != null && widget.edit!.parent != 0 ? Store.I.byId(widget.edit!.parent) : null;
  late final title = TextEditingController(text: widget.edit?.title ?? '');
  late final person = TextEditingController(text: widget.edit?.person ?? '');
  late final phone = TextEditingController(text: widget.edit?.phone ?? '');
  late String date = widget.edit?.date ?? widget.date ?? todayKey();
  late String? time = widget.edit?.time ?? (widget.type == 'meeting' ? '14:00' : null);
  late bool priority = (widget.edit?.priority ?? 0) > 0;
  String tpl = '';
  // repeat
  late String repeat = tp?.repeat ?? '';
  late Set<int> days = {...(tp?.repeatDays ?? <int>[])};
  late String endMode = tp == null ? 'never' : tp!.repeatCount > 0 ? 'count' : tp!.repeatUntil.isNotEmpty ? 'until' : 'never';
  late String until = tp?.repeatUntil.isNotEmpty == true ? tp!.repeatUntil : daysFrom(90);
  late final count = TextEditingController(text: '${tp?.repeatCount != null && tp!.repeatCount > 0 ? tp!.repeatCount : 10}');

  bool get meeting => widget.type == 'meeting';

  void applyRule(Item x) {
    x
      ..repeat = repeat
      ..repeatDays = days.toList()
      ..repeatUntil = endMode == 'until' ? until : ''
      ..repeatCount = endMode == 'count' ? (int.tryParse(count.text) ?? 0) : 0;
  }

  void copyFields(Item x) {
    x
      ..title = title.text.trim()
      ..time = time
      ..person = person.text.trim()
      ..phone = phone.text.trim()
      ..priority = priority ? 1 : 0;
  }

  Future<void> save() async {
    final st = Store.I;
    if (title.text.trim().isEmpty) {
      toast(context, t('नाव टाका', 'Enter a title'));
      return;
    }
    if (repeat == 'weekly' && days.isEmpty) {
      toast(context, t('कोणते वार ते निवडा', 'Pick the weekdays'));
      return;
    }
    final e = widget.edit;
    st.upsertContact(person.text, phone.text);
    if (e == null) {
      if (repeat.isEmpty) {
        st.add(Item(
          id: st.newId(), type: widget.type, title: title.text.trim(), date: date, time: time,
          person: person.text.trim(), phone: phone.text.trim(), priority: priority ? 1 : 0,
          points: (meetingTemplates[tpl] ?? []).map((x) => Point(x)).toList(),
        ));
      } else {
        final t0 = Item(id: st.newId(), type: widget.type, date: date, tpl: true);
        copyFields(t0);
        applyRule(t0);
        st.add(t0);
        final first = st.items.where((x) => x.parent == t0.id).toList();
        if (first.isNotEmpty && tpl.isNotEmpty) {
          sortItems(first).first.points = (meetingTemplates[tpl] ?? []).map((x) => Point(x)).toList();
        }
        st.save();
      }
    } else if (tp != null) {
      final all = await askScope(context, t('कशावर बदल लागू करायचा?', 'Apply changes to?'));
      if (all == null) return;
      copyFields(e);
      e.date = date;
      if (all) {
        copyFields(tp!);
        applyRule(tp!);
        if (repeat.isEmpty) tp!.repeatUntil = shiftKey(e.date, -1);
        // regenerate future untouched occurrences
        st.items.removeWhere((x) => x.parent == tp!.id && x.id != e.id && !x.done && x.points.isEmpty && x.date.compareTo(e.date) > 0);
        if (repeat.isNotEmpty) st.materialize();
      }
      st.save();
    } else {
      copyFields(e);
      e.date = date;
      if (repeat.isNotEmpty) {
        final t0 = Item(id: st.newId(), type: e.type, date: e.date, tpl: true, skips: [e.date]);
        copyFields(t0);
        applyRule(t0);
        e
          ..parent = t0.id
          ..series = t0.id;
        st.add(t0);
      } else {
        st.save();
      }
    }
    if (mounted) {
      toast(context, time != null ? t('✔ सेव्ह — ⏰ रिमाइंडर लागला', '✔ Saved — ⏰ reminder set') : t('✔ सेव्ह', '✔ Saved'));
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final contacts = Store.I.contacts;
    final templates = meetingTemplates;
    Widget chip(String v, String label) => ChoiceChip(label: Text(label), selected: repeat == v, onSelected: (_) => setState(() => repeat = v));
    return Scaffold(
      appBar: AppBar(title: Text(widget.edit != null ? t('बदला', 'Edit') : meeting ? t('🤝 नवीन मीटिंग', '🤝 New meeting') : t('✅ नवीन काम', '✅ New task'))),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        if (meeting && widget.edit == null) ...[
          Text(t('Template', 'Template'), style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, runSpacing: 6, children: [
            ChoiceChip(label: Text(t('रिकामी', 'Blank')), selected: tpl.isEmpty, onSelected: (_) => setState(() => tpl = '')),
            for (final k in templates.keys)
              ChoiceChip(
                  label: Text(k),
                  selected: tpl == k,
                  onSelected: (_) => setState(() {
                        tpl = k;
                        if (title.text.isEmpty) title.text = k;
                      })),
          ]),
          const SizedBox(height: 14),
        ],
        TextField(controller: title, autofocus: widget.edit == null, decoration: InputDecoration(labelText: meeting ? t('मीटिंगचं नाव', 'Meeting title') : t('काम', 'Task'))),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () async {
                final d = await pickDate(context, date);
                if (d != null) setState(() => date = d);
              },
              icon: const Icon(Icons.event),
              label: Text(nice(date)),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () async {
                final x = await pickTime(context, time);
                if (x != null) setState(() => time = x);
              },
              icon: const Icon(Icons.schedule),
              label: Text(time ?? t('वेळ (optional)', 'Time (optional)')),
            ),
          ),
          if (time != null) IconButton(onPressed: () => setState(() => time = null), icon: const Icon(Icons.close)),
        ]),
        const Section('🔁 Repeat'),
        Wrap(spacing: 8, runSpacing: 6, children: [
          chip('', t('एकदाच', 'Once')),
          chip('daily', t('रोज', 'Daily')),
          chip('weekdays', t('सोम–शुक्र', 'Mon–Fri')),
          chip('weekly', t('निवडक वार', 'Pick days')),
          chip('monthly', t('दर महिन्याला', 'Monthly')),
        ]),
        if (repeat == 'weekly') ...[
          const SizedBox(height: 10),
          Wrap(spacing: 6, runSpacing: 6, children: [
            for (var w = 1; w <= 7; w++)
              FilterChip(
                label: Text(wd(w)),
                selected: days.contains(w),
                onSelected: (v) => setState(() => v ? days.add(w) : days.remove(w)),
              ),
          ]),
        ],
        if (repeat == 'monthly')
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(t('दर महिन्याला ${parseKey(date)?.day} तारखेला', 'Every month on day ${parseKey(date)?.day}'), style: TextStyle(color: hint(context))),
          ),
        if (repeat.isNotEmpty) ...[
          const SizedBox(height: 12),
          Text(t('कधीपर्यंत', 'Ends'), style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, runSpacing: 6, crossAxisAlignment: WrapCrossAlignment.center, children: [
            ChoiceChip(label: Text(t('कायम', 'Never')), selected: endMode == 'never', onSelected: (_) => setState(() => endMode = 'never')),
            ChoiceChip(label: Text(t('तारखेपर्यंत', 'On date')), selected: endMode == 'until', onSelected: (_) => setState(() => endMode = 'until')),
            ChoiceChip(label: Text(t('ठराविक वेळा', 'After N times')), selected: endMode == 'count', onSelected: (_) => setState(() => endMode = 'count')),
          ]),
          if (endMode == 'until')
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: OutlinedButton.icon(
                onPressed: () async {
                  final d = await pickDate(context, until);
                  if (d != null) setState(() => until = d);
                },
                icon: const Icon(Icons.event_available),
                label: Text(nice(until)),
              ),
            ),
          if (endMode == 'count')
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: SizedBox(
                width: 160,
                child: TextField(controller: count, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: t('किती वेळा', 'How many times'))),
              ),
            ),
        ],
        const SizedBox(height: 16),
        TextField(
            controller: person,
            decoration: InputDecoration(labelText: t('कोणासोबत / कोणासाठी (optional)', 'With / for whom (optional)')),
            onChanged: (v) {
              final c = Store.I.contact(v.trim());
              if (c != null && c.phone.isNotEmpty) phone.text = c.phone;
            }),
        if (contacts.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Wrap(spacing: 6, runSpacing: 6, children: [
              for (final c in contacts.take(8))
                ActionChip(
                    label: Text(c.name),
                    onPressed: () => setState(() {
                          person.text = c.name;
                          phone.text = c.phone;
                        })),
            ]),
          ),
        if (meeting) ...[
          const SizedBox(height: 12),
          TextField(controller: phone, keyboardType: TextInputType.phone, decoration: InputDecoration(labelText: t('WhatsApp नंबर (optional)', 'WhatsApp number (optional)'))),
        ],
        if (!meeting)
          SwitchListTile(contentPadding: EdgeInsets.zero, value: priority, onChanged: (v) => setState(() => priority = v), title: const Text('⭐ Priority')),
        const SizedBox(height: 20),
        FilledButton(onPressed: save, child: Text(t('सेव्ह करा', 'Save'))),
      ]),
    );
  }
}
