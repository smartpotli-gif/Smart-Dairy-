import 'dart:async';
import 'package:flutter/material.dart';
import '../ai.dart';
import '../l10n.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../util.dart';
import '../widgets.dart';
import 'eod.dart';
import 'forms.dart';
import 'notes.dart';
import 'settings.dart';
import 'summary.dart';
import 'trip.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) {
          final s = Store.I.s;
          return Scaffold(
            appBar: AppBar(
              titleSpacing: 18,
              title: Text('Smart Diary', style: TextStyle(fontWeight: FontWeight.w700, color: headColor(context))),
              actions: [
                Padding(
                  padding: const EdgeInsets.only(right: 14),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(30),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage())),
                    child: CircleAvatar(
                      backgroundColor: C.gold,
                      child: Text(s.name.isEmpty ? '?' : s.name.characters.first, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                    ),
                  ),
                ),
              ],
            ),
            body: IndexedStack(index: tab, children: const [TodayTab(), CalendarTab(), TasksTab(), NotesTab(), MoreTab()]),
            bottomNavigationBar: NavigationBar(
              selectedIndex: tab,
              onDestinationSelected: (i) => setState(() => tab = i),
              destinations: [
                NavigationDestination(icon: const Icon(Icons.today_outlined), selectedIcon: const Icon(Icons.today), label: t('आज', 'Today')),
                NavigationDestination(icon: const Icon(Icons.calendar_month_outlined), selectedIcon: const Icon(Icons.calendar_month), label: t('कॅलेंडर', 'Calendar')),
                NavigationDestination(icon: const Icon(Icons.check_circle_outline), selectedIcon: const Icon(Icons.check_circle), label: t('कामं', 'Tasks')),
                NavigationDestination(icon: const Icon(Icons.menu_book_outlined), selectedIcon: const Icon(Icons.menu_book), label: t('नोट्स', 'Notes')),
                NavigationDestination(icon: const Icon(Icons.more_horiz), label: t('अधिक', 'More')),
              ],
            ),
          );
        },
      );
}

class TodayTab extends StatefulWidget {
  const TodayTab({super.key});
  @override
  State<TodayTab> createState() => _TodayTabState();
}

class _TodayTabState extends State<TodayTab> {
  final input = TextEditingController();
  Timer? timer;
  String day = todayKey();
  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (!mounted) return;
      if (day != todayKey()) {
        day = todayKey();
        Store.I.materialize();
        Store.I.save();
      }
      setState(() {});
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  void quickAdd() {
    final tx = input.text.trim();
    if (tx.isEmpty) return;
    final p = parseNatural(tx);
    final st = Store.I;
    st.add(Item(id: st.newId(), type: p.type, title: p.title, date: p.date, time: p.time));
    input.clear();
    FocusScope.of(context).unfocus();
    toast(context, '${p.type == 'meeting' ? t('🤝 मीटिंग', '🤝 Meeting') : t('✅ काम', '✅ Task')} — ${dayLabel(p.date)}${p.time != null ? ' · ⏰ ${p.time}' : ''}');
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) {
          final st = Store.I, today = todayKey(), hm = nowHM();
          final missed = sortItems(st.items.where((e) => isMissed(e) || (st.justToggled.contains(e.id) && e.date.compareTo(today) < 0)).toList());
          final todays = st.timedOn(today);
          final next = todays.where((e) => (!e.done || st.justToggled.contains(e.id)) && (e.time == null || e.time!.compareTo(hm) >= 0)).toList();
          final done = todays.where((e) => e.done && !st.justToggled.contains(e.id)).toList();
          final coming = sortItems(st.live.where((e) => (e.type == 'meeting' || e.type == 'trip') && !e.done && e.date.compareTo(today) > 0).toList()).take(4).toList();
          void go(Widget w) => Navigator.push(context, MaterialPageRoute(builder: (_) => w));
          Widget quick(String icon, String label, VoidCallback f, {bool ai = false}) => Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: Material(
                    color: ai ? Colors.transparent : Theme.of(context).colorScheme.surface,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: ai ? BorderSide.none : BorderSide(color: Theme.of(context).dividerColor)),
                    child: Ink(
                      decoration: ai ? BoxDecoration(gradient: const LinearGradient(colors: [C.aiA, C.aiB]), borderRadius: BorderRadius.circular(14)) : null,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(14),
                        onTap: f,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          child: Column(children: [
                            Text(icon, style: const TextStyle(fontSize: 20)),
                            Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, color: ai ? Colors.white : null)),
                          ]),
                        ),
                      ),
                    ),
                  ),
                ),
              );
          return ListView(padding: const EdgeInsets.fromLTRB(18, 4, 18, 28), children: [
            Text('${t('आज', 'Today')} · $hm', style: TextStyle(color: hint(context))),
            Text(fmt(DateTime.now(), 'EEEE, d MMMM'), style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: headColor(context))),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: TextField(
                  controller: input,
                  textInputAction: TextInputAction.done,
                  onSubmitted: (_) => quickAdd(),
                  decoration: InputDecoration(prefixIcon: const Icon(Icons.add), hintText: t('उदा. आज 2 वाजता मीटिंग आहे', 'e.g. meeting today 2 pm')),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: quickAdd, icon: const Icon(Icons.arrow_upward)),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              quick('🤝', t('मीटिंग', 'Meeting'), () => go(const ItemFormPage(type: 'meeting'))),
              quick('📝', t('नोट', 'Note'), () => go(const NoteEditPage())),
              quick('📋', t('सारांश', 'Summary'), () => go(const SummaryPage())),
              quick('✈️', t('ट्रिप', 'Trip'), () => go(const TripFormPage())),
              if (st.s.aiOn) quick('✨', 'AI', () => go(const AskAiPage()), ai: true),
            ]),
            if (missed.isNotEmpty) ...[
              Section('🔴 ${t('चुकलेलं', 'Missed')} (${missed.length})', color: redText(context)),
              ...missed.map((e) => ItemTile(e, missed: !e.done)),
            ],
            Section('⏰ ${t('आता पुढे', 'Up next')}'),
            if (next.isEmpty) Empty(t('आज पुढे काही नाही.', 'Nothing more today.')),
            for (var i = 0; i < next.length; i++)
              ItemTile(next[i], countdown: i == 0 && next[i].time != null && !next[i].done ? timeLeft(next[i].time!) : null),
            if (coming.isNotEmpty) ...[Section('📅 ${t('पुढे येणारं', 'Coming up')}'), ...coming.map((e) => ItemTile(e))],
            if (done.isNotEmpty) ...[
              Section('✔ ${t('झालेलं', 'Done')} (${done.length})', color: hint(context)),
              ...done.map((e) => ItemTile(e)),
            ],
            const SizedBox(height: 14),
            OutlinedButton.icon(
              onPressed: () => go(const EodPage()),
              icon: const Text('🌙'),
              label: Text(t('दिवसाचा शेवट', 'End of day')),
            ),
            if (!AI.ready && st.s.aiOn) ...[
              const SizedBox(height: 12),
              Card(
                child: ListTile(
                  leading: const Text('✨', style: TextStyle(fontSize: 22)),
                  title: Text(t('AI चालू करा (मोफत)', 'Turn on AI (free)')),
                  subtitle: Text(t('Settings मध्ये Gemini key टाका', 'Add a Gemini key in Settings')),
                  onTap: () => go(const SettingsPage()),
                ),
              ),
            ],
          ]);
        },
      );
}

class CalendarTab extends StatefulWidget {
  const CalendarTab({super.key});
  @override
  State<CalendarTab> createState() => _CalendarTabState();
}

class _CalendarTabState extends State<CalendarTab> {
  DateTime month = DateTime(DateTime.now().year, DateTime.now().month);
  String sel = todayKey();
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) {
          final st = Store.I;
          final cs = Theme.of(context).colorScheme;
          final days = DateTime(month.year, month.month + 1, 0).day;
          final lead = DateTime(month.year, month.month, 1).weekday - 1; // Monday first
          final live = st.live;
          final has = live.map((e) => e.date).toSet();
          final list = sortItems(live.where((e) => e.date == sel).toList());
          return ListView(padding: const EdgeInsets.fromLTRB(18, 4, 18, 28), children: [
            Row(children: [
              IconButton(onPressed: () => setState(() => month = DateTime(month.year, month.month - 1)), icon: const Icon(Icons.chevron_left)),
              Expanded(child: Center(child: Text(fmt(month, 'MMMM yyyy'), style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: headColor(context))))),
              IconButton(onPressed: () => setState(() => month = DateTime(month.year, month.month + 1)), icon: const Icon(Icons.chevron_right)),
            ]),
            GridView.count(
              crossAxisCount: 7,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                for (var w = 1; w <= 7; w++) Center(child: Text(wd(w), style: TextStyle(color: hint(context), fontSize: 12))),
                for (var i = 0; i < lead; i++) const SizedBox(),
                for (var d = 1; d <= days; d++)
                  Builder(builder: (_) {
                    final k = dkey(DateTime(month.year, month.month, d));
                    final isSel = k == sel;
                    return InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => setState(() => sel = k),
                      child: Container(
                        margin: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                            color: isSel ? cs.primary : null,
                            borderRadius: BorderRadius.circular(12),
                            border: k == todayKey() && !isSel ? Border.all(color: C.gold) : null),
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Text('$d', style: TextStyle(color: isSel ? cs.onPrimary : cs.onSurface, fontWeight: k == todayKey() ? FontWeight.w700 : null)),
                          if (has.contains(k)) Container(width: 5, height: 5, decoration: const BoxDecoration(color: C.gold, shape: BoxShape.circle)),
                        ]),
                      ),
                    );
                  }),
              ],
            ),
            Section(nice(sel), trailing: IconButton(
              tooltip: t('या दिवशी काम ॲड करा', 'Add on this day'),
              icon: const Icon(Icons.add),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ItemFormPage(type: 'meeting', date: sel))),
            )),
            if (list.isEmpty) Empty(t('या दिवशी काही नाही.', 'Nothing on this day.')),
            ...list.map((e) => e.isNote ? NoteTile(e) : ItemTile(e)),
          ]);
        },
      );
}

class TasksTab extends StatelessWidget {
  const TasksTab({super.key});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) {
          final st = Store.I;
          final horizon = daysFrom(7);
          final all = sortItems(st.live.where((e) => !e.isNote).toList());
          final pending = all.where((e) => (!e.done || st.justToggled.contains(e.id)) && (e.parent == 0 || e.date.compareTo(horizon) <= 0)).toList();
          final done = all.where((e) => e.done && !st.justToggled.contains(e.id)).toList().reversed.take(30).toList();
          return ListView(padding: const EdgeInsets.fromLTRB(18, 4, 18, 90), children: [
            Section('⏳ ${t('बाकी', 'Pending')} (${pending.length})',
                trailing: TextButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ItemFormPage(type: 'task'))),
                  icon: const Icon(Icons.add),
                  label: Text(t('काम', 'Task')),
                )),
            if (pending.isEmpty) Empty(t('सगळं झालं 🎉', 'All done 🎉')),
            ...pending.map((e) => ItemTile(e, missed: isMissed(e))),
            Text(t('🔁 repeat कामं पुढच्या 7 दिवसांची दिसतात', '🔁 Repeating items shown for the next 7 days'), style: TextStyle(fontSize: 11, color: hint(context))),
            Section('✔ ${t('पूर्ण', 'Completed')}', color: hint(context)),
            if (done.isEmpty) Empty(t('अजून काही नाही.', 'Nothing yet.')),
            ...done.map((e) => ItemTile(e)),
          ]);
        },
      );
}
