import 'package:flutter/material.dart';
import '../ai.dart';
import '../l10n.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../util.dart';
import '../widgets.dart';

/// End of day: today's done work, meetings with points, notes, pending; add more; save one diary note.
class EodPage extends StatefulWidget {
  const EodPage({super.key});
  @override
  State<EodPage> createState() => _EodPageState();
}

class _EodPageState extends State<EodPage> {
  final extra = TextEditingController();
  final ai = TextEditingController();
  bool busy = false, show = false;
  late final Item? existing = _find();

  Item? _find() {
    for (final e in Store.I.items) {
      if (e.kind == 'eod' && e.date == todayKey()) return e;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    final ex = existing;
    if (ex != null) {
      final i = ex.content.indexOf('✍️');
      if (i >= 0) extra.text = ex.content.substring(i).replaceFirst(RegExp(r'^✍️[^\n]*\n'), '').trim();
    }
  }

  String build_(List<Item> done, List<Item> meetings, List<Item> notes, List<Item> pending) {
    final b = StringBuffer();
    b.writeln('🌙 ${t('दिवसाचा शेवट', 'End of day')} — ${fmt(DateTime.now(), 'EEEE, d MMMM')}');
    if (done.isNotEmpty) {
      b.writeln('\n✅ ${t('पूर्ण झालेलं', 'Completed')}:');
      for (final e in done) {
        b.writeln('• ${e.time != null ? '${e.time} ' : ''}${e.title}');
      }
    }
    if (meetings.isNotEmpty) {
      b.writeln('\n🤝 ${t('मीटिंग्स', 'Meetings')}:');
      for (final m in meetings) {
        b.writeln('• ${m.time != null ? '${m.time} ' : ''}${m.title}${m.person.isNotEmpty ? ' (${m.person})' : ''}${m.done ? ' ✔' : ''}');
        for (final p in m.points) {
          b.writeln('   ${p.d ? '✔' : '⏳'} ${p.t}');
        }
      }
    }
    if (notes.isNotEmpty) {
      b.writeln('\n📝 ${t('नोट्स', 'Notes')}:');
      for (final n in notes) {
        final first = n.content.split('\n').first;
        b.writeln('• ${n.title.isNotEmpty ? '${n.title}: ' : ''}${first.length > 80 ? '${first.substring(0, 80)}…' : first}');
      }
    }
    if (pending.isNotEmpty) {
      b.writeln('\n⏳ ${t('बाकी', 'Pending')}:');
      for (final e in pending) {
        b.writeln('• ${e.title}');
      }
    }
    if (extra.text.trim().isNotEmpty) {
      b.writeln('\n✍️ ${t('माझी नोंद', 'My note')}:');
      b.writeln(extra.text.trim());
    }
    return b.toString().trim();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) {
          final st = Store.I, today = todayKey();
          final live = st.live;
          final done = sortItems(live.where((e) => e.type == 'task' && e.done && e.date == today).toList());
          final meetings = sortItems(live.where((e) => e.type == 'meeting' && e.date == today).toList());
          final notes = live.where((e) => e.isNote && e.date == today && e.kind != 'eod').toList();
          final pending = sortItems(live.where((e) => e.type == 'task' && !e.done && e.date.compareTo(today) <= 0).toList());
          final h = hint(context);
          return Scaffold(
            appBar: AppBar(title: Text(t('🌙 दिवसाचा शेवट', '🌙 End of day'))),
            body: ListView(padding: const EdgeInsets.fromLTRB(18, 0, 18, 40), children: [
              Text(fmt(DateTime.now(), 'EEEE, d MMMM'), style: TextStyle(color: h)),
              Section('✅ ${t('आज पूर्ण झालेलं', 'Done today')} (${done.length})'),
              if (done.isEmpty) Empty(t('आज टिक केलेलं काही नाही.', 'Nothing ticked today.')),
              ...done.map((e) => Text('• ${e.time != null ? '${e.time} ' : ''}${e.title}', style: const TextStyle(height: 1.6))),
              Section('🤝 ${t('आजच्या मीटिंग्स', "Today's meetings")} (${meetings.length})'),
              if (meetings.isEmpty) Empty(t('आज मीटिंग नव्हती.', 'No meetings today.')),
              for (final m in meetings)
                Card(
                  color: meetingBg(context),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${m.time != null ? '${m.time} · ' : ''}${m.title}${m.person.isNotEmpty ? ' · ${m.person}' : ''}${m.done ? '  ✔' : ''}',
                          style: const TextStyle(fontWeight: FontWeight.w600)),
                      if (m.points.isEmpty) Text(t('पॉइंट्स नाहीत', 'No points'), style: TextStyle(color: h, fontSize: 12)),
                      ...m.points.map((p) => Text('${p.d ? '✔' : '⏳'} ${p.t}', style: const TextStyle(fontSize: 13.5))),
                    ]),
                  ),
                ),
              Section('📝 ${t('आजच्या नोट्स', "Today's notes")} (${notes.length})'),
              if (notes.isEmpty) Empty(t('आज नोट नाही.', 'No notes today.')),
              ...notes.map((n) => Text('• ${n.title.isNotEmpty ? '${n.title}: ' : ''}${n.content.split('\n').first}', maxLines: 2, overflow: TextOverflow.ellipsis)),
              Section('⏳ ${t('बाकी राहिलेलं', 'Still pending')} (${pending.length})',
                  trailing: pending.isEmpty
                      ? null
                      : TextButton(
                          onPressed: () {
                            for (final e in pending) {
                              e.date = daysFrom(1);
                            }
                            st.save();
                            toast(context, t('➡️ ${pending.length} कामं उद्यावर', '➡️ ${pending.length} tasks moved to tomorrow'));
                          },
                          child: Text(t('सगळी उद्यावर ➡️', 'All to tomorrow ➡️')))),
              if (pending.isEmpty) Empty(t('काही बाकी नाही 🎉', 'Nothing pending 🎉')),
              for (final e in pending)
                Row(children: [
                  Expanded(child: Text('• ${e.title}')),
                  TextButton(
                      onPressed: () {
                        e.date = daysFrom(1);
                        st.save();
                      },
                      child: Text(t('उद्या', 'Tomorrow'))),
                ]),
              Section(t('✍️ अजून काही लिहायचं', '✍️ Anything to add')),
              TextField(controller: extra, maxLines: null, minLines: 4, decoration: InputDecoration(hintText: t('आज काय शिकलो, उद्या काय करायचं…', 'What I learned, what to do tomorrow…'))),
              const SizedBox(height: 14),
              FilledButton(
                onPressed: () {
                  final content = build_(done, meetings, notes, pending);
                  final ex = existing ?? _find();
                  if (ex != null) {
                    ex.content = content;
                    st.save(reschedule: false);
                  } else {
                    st.add(Item(
                        id: st.newId(), type: 'note', kind: 'eod', title: t('दिवसाचा शेवट', 'End of day'), content: content, date: today,
                        tags: [t('दिवसाचा शेवट', 'End of day')]));
                  }
                  toast(context, t('💾 आजची डायरी नोंद सेव्ह झाली', "💾 Today's diary note saved"));
                  Navigator.pop(context);
                },
                child: Text(t('💾 नोंद सेव्ह करा', '💾 Save diary note')),
              ),
              if (AI.ready) ...[
                const SizedBox(height: 10),
                AiButton(t('✨ दिवसाचा AI सारांश', '✨ AI summary of the day'), busy: busy, onTap: () async {
                  setState(() {
                    busy = true;
                    show = true;
                    ai.text = t('✨ विचार करतोय…', '✨ Thinking…');
                  });
                  try {
                    ai.text = await AI.ask('${AI.header()}\nमाझ्या आजच्या कामाचा ${AI.lang()} छोटा रिपोर्ट बनव (वरिष्ठांना पाठवता येईल असा): काय पूर्ण झालं, मीटिंग्समध्ये काय ठरलं, काय बाकी आहे.\n\n'
                        '${AI.clean(build_(done, meetings, notes, pending))}');
                  } catch (err) {
                    ai.text = err.toString();
                  }
                  if (mounted) setState(() => busy = false);
                }),
                if (show) ResultBox(ctrl: ai, subject: t('आजचा रिपोर्ट', "Today's report")),
              ],
            ]),
          );
        },
      );
}
