import 'package:flutter/material.dart';
import '../l10n.dart';
import '../store.dart';
import '../theme.dart';
import '../util.dart';
import '../widgets.dart';
import 'notes.dart';
import 'summary.dart';

class PeoplePage extends StatelessWidget {
  const PeoplePage({super.key});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) {
          final st = Store.I;
          final l = [...st.contacts]..sort((a, b) => a.name.compareTo(b.name));
          return Scaffold(
            appBar: AppBar(title: Text(t('👥 संपर्क', '👥 Contacts'))),
            body: ListView(padding: const EdgeInsets.all(18), children: [
              if (l.isEmpty) Empty(t('मीटिंग किंवा सारांशमध्ये नाव टाकलं की इथे येईल.', 'Names from meetings or summaries appear here.')),
              for (final c in l)
                Card(
                  child: ListTile(
                    leading: CircleAvatar(backgroundColor: C.gold, child: Text(c.name.characters.first, style: const TextStyle(color: Colors.white))),
                    title: Text(c.name),
                    subtitle: Text('${c.phone}  ·  ${st.live.where((e) => e.person == c.name).length} ${t('नोंदी', 'entries')}'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PersonPage(name: c.name))),
                  ),
                ),
            ]),
          );
        },
      );
}

class PersonPage extends StatelessWidget {
  final String name;
  const PersonPage({super.key, required this.name});

  Future<void> editContact(BuildContext context) async {
    final st = Store.I;
    st.upsertContact(name, '');
    final c = st.contact(name)!;
    final phone = TextEditingController(text: c.phone), company = TextEditingController(text: c.company);
    await showDialog(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(name),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: phone, keyboardType: TextInputType.phone, decoration: InputDecoration(labelText: t('नंबर', 'Phone'))),
          const SizedBox(height: 10),
          TextField(controller: company, decoration: InputDecoration(labelText: t('कंपनी', 'Company'))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: Text(t('रद्द', 'Cancel'))),
          FilledButton(
              onPressed: () {
                c.phone = phone.text.trim();
                c.company = company.text.trim();
                st.save(reschedule: false);
                Navigator.pop(d);
              },
              child: Text(t('सेव्ह', 'Save'))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) {
          final st = Store.I;
          final c = st.contact(name);
          final live = st.live;
          final meetings = sortItems(live.where((e) => e.type == 'meeting' && e.person == name).toList()).reversed.take(20).toList();
          final tasks = live.where((e) => e.type == 'task' && !e.done && e.person == name).toList();
          final sums = live.where((e) => e.isNote && e.person == name).toList().reversed.toList();
          return Scaffold(
            appBar: AppBar(title: Text('👤 $name'), actions: [IconButton(icon: const Icon(Icons.edit), onPressed: () => editContact(context))]),
            body: ListView(padding: const EdgeInsets.fromLTRB(18, 0, 18, 40), children: [
              if (c != null && (c.phone.isNotEmpty || c.company.isNotEmpty)) Text('${c.company}  ${c.phone}', style: TextStyle(color: hint(context))),
              const SizedBox(height: 10),
              Row(children: [
                if (c != null && c.phone.isNotEmpty) ...[
                  Expanded(
                      child: FilledButton(
                          style: FilledButton.styleFrom(backgroundColor: C.wa, foregroundColor: Colors.white),
                          onPressed: () => openWhatsApp(context, c.phone, ''),
                          child: const Text('📲 WhatsApp'))),
                  const SizedBox(width: 8),
                ],
                Expanded(
                    child: FilledButton.tonal(
                        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SummaryPage(person: name))), child: Text(t('📋 नवीन सारांश', '📋 New summary')))),
              ]),
              Section('⏳ ${t('बाकी कामं', 'Pending tasks')} (${tasks.length})'),
              if (tasks.isEmpty) Empty(t('काही बाकी नाही.', 'Nothing pending.')),
              ...tasks.map((e) => ItemTile(e)),
              Section('🤝 ${t('मीटिंग्स', 'Meetings')} (${meetings.length})'),
              if (meetings.isEmpty) Empty(t('मीटिंग्स नाहीत.', 'No meetings.')),
              ...meetings.map((e) => ItemTile(e)),
              Section('📋 ${t('सारांश / नोट्स', 'Summaries / notes')} (${sums.length})'),
              if (sums.isEmpty) Empty(t('अजून नाहीत.', 'None yet.')),
              ...sums.map((e) => NoteTile(e, showDate: true)),
            ]),
          );
        },
      );
}
