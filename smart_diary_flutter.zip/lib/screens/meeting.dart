import 'package:flutter/material.dart';
import '../ai.dart';
import '../l10n.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../util.dart';
import '../widgets.dart';
import 'forms.dart';

class MeetingPage extends StatefulWidget {
  final int id;
  const MeetingPage({super.key, required this.id});
  @override
  State<MeetingPage> createState() => _MeetingPageState();
}

class _MeetingPageState extends State<MeetingPage> {
  final point = TextEditingController();
  final aiOut = TextEditingController();
  bool busy = false, showAi = false;
  String nextDate = daysFrom(2), nextTime = '17:00';

  Future<void> runAi(String prompt) async {
    setState(() {
      busy = true;
      showAi = true;
      aiOut.text = t('✨ विचार करतोय…', '✨ Thinking…');
    });
    try {
      aiOut.text = await AI.ask(prompt);
    } catch (err) {
      aiOut.text = err.toString();
    }
    if (mounted) setState(() => busy = false);
  }

  String waMsg(Item e) => isEn
      ? 'Hello${e.person.isNotEmpty ? ' ${e.person}' : ''}, our "${e.title}" meeting is on ${nice(e.date)}${e.time != null ? ' at ${e.time}' : ''}.'
      : 'नमस्कार${e.person.isNotEmpty ? ' ${e.person}' : ''}, आपली "${e.title}" मीटिंग ${nice(e.date)}${e.time != null ? ' रोजी ${e.time} वाजता' : ''} आहे.';

  void addPoint(Item e) {
    final v = point.text.trim();
    if (v.isEmpty) return;
    e.points.add(Point(v));
    point.clear();
    Store.I.save(reschedule: false);
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) {
          final st = Store.I;
          final e = st.byId(widget.id);
          if (e == null) return Scaffold(appBar: AppBar(), body: Center(child: Text(t('ही मीटिंग डिलीट झाली.', 'This meeting was deleted.'))));
          final tp = e.parent != 0 ? st.byId(e.parent) : null;
          final prev = sortItems(st.items
                  .where((x) => !x.tpl && x.type == 'meeting' && x.series == e.series && x.id != e.id && (x.date + (x.time ?? '')).compareTo(e.date + (e.time ?? '')) < 0)
                  .toList())
              .reversed
              .take(6)
              .toList();
          final minutes = '${e.title} — ${nice(e.date)}${e.time != null ? ' ${e.time}' : ''}\n${e.points.map((p) => '${p.d ? '✅' : '⏳'} ${p.t}').join('\n')}';
          return Scaffold(
            appBar: AppBar(title: Text('🤝 ${e.title}', overflow: TextOverflow.ellipsis), actions: [
              IconButton(icon: const Icon(Icons.edit), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ItemFormPage(type: 'meeting', edit: e)))),
              IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    if (await deleteItem(context, e) && context.mounted) Navigator.pop(context);
                  }),
            ]),
            body: ListView(padding: const EdgeInsets.fromLTRB(18, 0, 18, 40), children: [
              Text('${dayLabel(e.date)} · ${nice(e.date)}${e.time != null ? ' · ⏰ ${e.time}' : ''}', style: TextStyle(color: hint(context))),
              if (tp != null) Text('🔁 ${repeatLabel(tp)}', style: const TextStyle(color: C.gold, fontWeight: FontWeight.w600)),
              if (e.person.isNotEmpty || e.phone.isNotEmpty) ...[
                Section(t('👤 कोणासोबत', '👤 With')),
                Card(
                  child: ListTile(
                    title: Text(e.person.isEmpty ? t('संपर्क', 'Contact') : e.person),
                    subtitle: e.phone.isEmpty ? null : Text(e.phone),
                    trailing: e.phone.isEmpty
                        ? null
                        : Row(mainAxisSize: MainAxisSize.min, children: [
                            IconButton(icon: const Icon(Icons.call), onPressed: () => openUrl(context, 'tel:${e.phone}')),
                            FilledButton(
                              style: FilledButton.styleFrom(backgroundColor: C.wa, foregroundColor: Colors.white),
                              onPressed: () => openWhatsApp(context, e.phone, waMsg(e)),
                              child: const Text('📲 WhatsApp'),
                            ),
                          ]),
                  ),
                ),
              ],
              Section('📝 ${t('पॉइंट्स', 'Points')} (${e.points.length})',
                  trailing: e.points.isEmpty ? null : IconButton(icon: const Icon(Icons.copy, size: 20), onPressed: () => copyText(context, minutes))),
              if (e.points.isEmpty) Empty(t('मीटिंगमध्ये झालेले मुद्दे इथे लिहा.', 'Write the meeting points here.')),
              for (var i = 0; i < e.points.length; i++)
                Card(
                  child: Row(children: [
                    Checkbox(
                        value: e.points[i].d,
                        onChanged: (_) {
                          e.points[i].d = !e.points[i].d;
                          st.save(reschedule: false);
                        }),
                    Expanded(child: Text(e.points[i].t, style: TextStyle(decoration: e.points[i].d ? TextDecoration.lineThrough : null))),
                    IconButton(
                        tooltip: t('टास्क बनवा', 'Make a task'),
                        icon: const Icon(Icons.add_task, size: 20),
                        onPressed: () {
                          st.add(Item(id: st.newId(), type: 'task', title: e.points[i].t, date: todayKey(), person: e.person));
                          toast(context, t('✅ कामांमध्ये ॲड', '✅ Added to tasks'));
                        }),
                    IconButton(
                        icon: const Icon(Icons.close, size: 18),
                        onPressed: () {
                          e.points.removeAt(i);
                          st.save(reschedule: false);
                        }),
                  ]),
                ),
              Row(children: [
                Expanded(
                  child: TextField(
                    controller: point,
                    textInputAction: TextInputAction.done,
                    decoration: InputDecoration(hintText: t('पॉइंट लिहा…', 'Write a point…')),
                    onSubmitted: (_) => addPoint(e),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: () => addPoint(e), icon: const Icon(Icons.add)),
              ]),
              if (AI.ready) ...[
                const Section('✨ AI'),
                Row(children: [
                  Expanded(
                    child: AiButton(t('📝 सारांश', '📝 Summary'), busy: busy, onTap: () {
                      if (e.points.isEmpty) {
                        toast(context, t('आधी पॉइंट्स टाका', 'Add points first'));
                        return;
                      }
                      runAi('${AI.header()}\nया मीटिंगच्या पॉइंट्सवरून ${AI.lang()} छोटी Minutes बनव: 1) काय ठरलं 2) Action items (कोण, काय, कधी) 3) पुढच्या मीटिंगमध्ये काय बघायचं.\n'
                          'मीटिंग: ${e.title}, ${e.date}${e.person.isNotEmpty ? ', सोबत ${e.person}' : ''}\n${AI.clean(e.points.map((p) => '- ${p.t}${p.d ? ' (झालं)' : ''}').join('\n'))}');
                    }),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: AiButton(t('📲 WhatsApp मेसेज', '📲 WhatsApp draft'), busy: busy, onTap: () {
                      runAi('${AI.header()}\n${e.person.isEmpty ? 'समोरच्या व्यक्ती' : e.person}ला पाठवण्यासाठी छोटा, नम्र WhatsApp follow-up मेसेज ${AI.lang()} लिही (3-4 ओळी). '
                          'मीटिंग: ${e.title}, ${nice(e.date)} ${e.time ?? ''}. पॉइंट्स: ${AI.clean(e.points.map((p) => p.t).join('; '))}. फक्त मेसेज दे.');
                    }),
                  ),
                ]),
                if (showAi) ResultBox(ctrl: aiOut, subject: '${e.title} — Minutes'),
                if (showAi && e.phone.isNotEmpty)
                  TextButton(onPressed: () => openWhatsApp(context, e.phone, aiOut.text), child: Text(t('📲 ${e.person.isEmpty ? 'contact' : e.person} ला थेट पाठवा', '📲 Send to ${e.person.isEmpty ? 'contact' : e.person}'))),
              ],
              if (prev.isNotEmpty) ...[
                Section(t('📎 मागच्या मीटिंगमध्ये काय झालं', '📎 What happened in earlier meetings')),
                for (final p in prev)
                  Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                        border: const Border(left: BorderSide(color: C.gold, width: 3)),
                        color: Theme.of(context).colorScheme.surface,
                        borderRadius: const BorderRadius.horizontal(right: Radius.circular(12))),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${nice(p.date)}${p.time != null ? ' · ${p.time}' : ''}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 4),
                      if (p.points.isEmpty) Text(t('पॉइंट्स नाहीत', 'No points'), style: TextStyle(color: hint(context))),
                      ...p.points.map((x) => Text('${x.d ? '✔️' : '⏳'} ${x.t}')),
                    ]),
                  ),
              ],
              if (tp == null) ...[
                Section(t('🔁 पुढची मीटिंग ठरवा', '🔁 Schedule the next meeting')),
                Row(children: [
                  Expanded(
                    child: OutlinedButton(
                        onPressed: () async {
                          final d = await pickDate(context, nextDate);
                          if (d != null) setState(() => nextDate = d);
                        },
                        child: Text(nice(nextDate))),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton(
                        onPressed: () async {
                          final x = await pickTime(context, nextTime);
                          if (x != null) setState(() => nextTime = x);
                        },
                        child: Text(nextTime)),
                  ),
                ]),
                const SizedBox(height: 8),
                FilledButton(
                  onPressed: () {
                    e.done = true;
                    final n = Item(
                        id: st.newId(),
                        type: 'meeting',
                        title: '${e.title.replaceAll(' (follow-up)', '')} (follow-up)',
                        date: nextDate,
                        time: nextTime,
                        series: e.series,
                        person: e.person,
                        phone: e.phone);
                    st.add(n);
                    toast(context, t('🔁 ${nice(nextDate)} $nextTime — मागचे पॉइंट्स तिथे दिसतील', '🔁 ${nice(nextDate)} $nextTime — earlier points will show there'));
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MeetingPage(id: n.id)));
                  },
                  child: Text(t('पुढची मीटिंग सेव्ह करा', 'Save next meeting')),
                ),
              ],
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () => st.toggleDone(e),
                child: Text(e.done ? t('↺ परत उघडा', '↺ Reopen') : t('✔ मीटिंग झाली', '✔ Meeting done')),
              ),
            ]),
          );
        },
      );
}
