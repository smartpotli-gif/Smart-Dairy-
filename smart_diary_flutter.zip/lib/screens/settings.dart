import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../ai.dart';
import '../cloud.dart';
import '../l10n.dart';
import '../store.dart';
import '../theme.dart';
import '../util.dart';
import '../widgets.dart';
import 'eod.dart';
import 'notes.dart';
import 'people.dart';
import 'start.dart';
import 'summary.dart';
import 'trip.dart';

Future<void> backup(BuildContext c) async {
  try {
    await Store.I.flush();
    final dir = await getTemporaryDirectory();
    final f = File('${dir.path}/SmartDiary-backup-${todayKey()}.json');
    await f.writeAsString(Store.I.backupJson());
    await Share.shareXFiles([XFile(f.path)], text: 'Smart Diary backup ${todayKey()}');
  } catch (_) {
    if (c.mounted) toast(c, t('Backup घेता आला नाही', 'Backup failed'));
  }
}

Future<void> restore(BuildContext c) async {
  try {
    final r = await FilePicker.platform.pickFiles(type: FileType.any);
    final path = r?.files.single.path;
    if (path == null || !c.mounted) return;
    if (!await confirm(c, t('सध्याचा डेटा बदलून backup मधला डेटा आणायचा?', 'Replace current data with the backup?'), ok: t('हो, आणा', 'Yes, restore'))) return;
    final ok = await Store.I.restore(await File(path).readAsString());
    if (c.mounted) toast(c, ok ? t('♻️ Backup परत आणला', '♻️ Backup restored') : t('ही Smart Diary backup फाइल नाही', 'Not a Smart Diary backup file'));
  } catch (_) {
    if (c.mounted) toast(c, t('फाइल वाचता आली नाही', 'Could not read the file'));
  }
}

void pasteIn(BuildContext c) {
  final tx = TextEditingController();
  showModalBottomSheet(
    context: c,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (s) => Padding(
      padding: EdgeInsets.fromLTRB(18, 0, 18, MediaQuery.of(s).viewInsets.bottom + 18),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(t('📥 मेसेजवरून नोंद', '📥 Entry from a message'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
        Text(t('WhatsApp/Email मधला मजकूर कॉपी करून इथे पेस्ट करा.', 'Copy text from WhatsApp/Email and paste it here.')),
        const SizedBox(height: 10),
        TextField(controller: tx, maxLines: 6, autofocus: true),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          FilledButton(
              onPressed: () {
                Navigator.pop(s);
                Navigator.push(c, MaterialPageRoute(builder: (_) => NoteEditPage(prefill: tx.text)));
              },
              child: Text(t('📝 नोट', '📝 Note'))),
          FilledButton(
              onPressed: () {
                Navigator.pop(s);
                Navigator.push(c, MaterialPageRoute(builder: (_) => AskAiPage(prefill: tx.text)));
              },
              child: Text(t('✨ काम/मीटिंग', '✨ Task/meeting'))),
          FilledButton(
              onPressed: () {
                Navigator.pop(s);
                Navigator.push(c, MaterialPageRoute(builder: (_) => SummaryPage(text: tx.text)));
              },
              child: Text(t('📋 सारांश', '📋 Summary'))),
        ]),
      ]),
    ),
  );
}

class MoreTab extends StatelessWidget {
  const MoreTab({super.key});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) {
          void go(Widget w) => Navigator.push(context, MaterialPageRoute(builder: (_) => w));
          Widget tile(String icon, String tl, String sub, VoidCallback f) =>
              Card(child: ListTile(leading: Text(icon, style: const TextStyle(fontSize: 22)), title: Text(tl), subtitle: sub.isEmpty ? null : Text(sub), onTap: f));
          return ListView(padding: const EdgeInsets.fromLTRB(18, 4, 18, 28), children: [
            tile('👥', t('संपर्क', 'Contacts'), t('व्यक्तीनुसार मीटिंग्स, सारांश, बाकी कामं', 'Meetings, summaries, pending tasks per person'), () => go(const PeoplePage())),
            tile('✈️', t('ट्रिप्स', 'Trips'), t('फ्लाइट, हॉटेल, कॅब एकत्र', 'Flight, hotel, cab together'), () => go(const TripsPage())),
            tile('📋', t('चर्चेचा सारांश', 'Discussion summary'), t('CA, vendor सोबतच्या बोलण्याचा सारांश', 'Summarise talks with CA, vendors'), () => go(const SummaryPage())),
            tile('📥', t('मेसेजवरून नोंद', 'Entry from a message'), t('WhatsApp/Email मधला मजकूर पेस्ट करा', 'Paste text from WhatsApp/Email'), () => pasteIn(context)),
            tile('🌙', t('दिवसाचा शेवट', 'End of day'), t('आजचा आढावा आणि डायरी नोंद', "Today's review and diary note"), () => go(const EodPage())),
            tile('💾', t('Backup घ्या', 'Take backup'), t('Drive / WhatsApp वर फाइल ठेवा', 'Keep the file on Drive / WhatsApp'), () => backup(context)),
            tile('♻️', t('Backup परत आणा', 'Restore backup'), '', () => restore(context)),
            tile('⚙️', t('सेटिंग्स', 'Settings'), '', () => go(const SettingsPage())),
            const SizedBox(height: 20),
            Center(child: BrandFooter(color: hint(context))),
          ]);
        },
      );
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final s = Store.I.s;
  late final name = TextEditingController(text: s.name);
  late final company = TextEditingController(text: s.company);
  late final key = TextEditingController(text: s.aiKey);
  late final model = TextEditingController(text: s.aiModel);
  bool testing = false;

  void save({bool reschedule = false}) => Store.I.save(reschedule: reschedule);

  Future<void> hourPick(int current, void Function(int) set) async {
    final tm = await showTimePicker(context: context, initialTime: TimeOfDay(hour: current, minute: 0));
    if (tm != null) {
      setState(() => set(tm.hour));
      save(reschedule: true);
    }
  }

  Future<void> setPin() async {
    final c = TextEditingController();
    final r = await showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(t('🔒 4 अंकी PIN', '🔒 4-digit PIN')),
        content: TextField(controller: c, keyboardType: TextInputType.number, maxLength: 4, obscureText: true, autofocus: true),
        actions: [
          if (s.pin.isNotEmpty) TextButton(onPressed: () => Navigator.pop(d, ''), child: Text(t('लॉक काढा', 'Remove lock'), style: TextStyle(color: redText(context)))),
          TextButton(onPressed: () => Navigator.pop(d), child: Text(t('रद्द', 'Cancel'))),
          FilledButton(onPressed: () => Navigator.pop(d, c.text), child: Text(t('सेव्ह', 'Save'))),
        ],
      ),
    );
    if (r == null) return;
    if (r.isNotEmpty && !RegExp(r'^\d{4}$').hasMatch(r)) {
      if (mounted) toast(context, t('4 अंक टाका', 'Enter 4 digits'));
      return;
    }
    setState(() => s.pin = r);
    save();
    if (mounted) toast(context, r.isEmpty ? t('लॉक बंद', 'Lock off') : t('🔒 लॉक चालू', '🔒 Lock on'));
  }

  Future<void> test() async {
    s.aiKey = key.text.trim();
    s.aiModel = model.text.trim().isEmpty ? 'gemini-flash-latest' : model.text.trim();
    save();
    setState(() => testing = true);
    try {
      await AI.ask('Reply only: OK');
      if (mounted) toast(context, t('✅ AI चालू आहे', '✅ AI is working'));
    } catch (e) {
      if (mounted) toast(context, e.toString());
    }
    if (mounted) setState(() => testing = false);
  }

  Future<void> editMsgs() async {
    final c = TextEditingController(text: s.customMsgs.join('\n'));
    final r = await showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(t('💬 तुमचे मेसेज', '💬 Your messages')),
        content: TextField(
            controller: c, maxLines: 8, decoration: InputDecoration(hintText: t('प्रत्येक ओळीत एक मेसेज.', 'One message per line.'))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: Text(t('रद्द', 'Cancel'))),
          FilledButton(onPressed: () => Navigator.pop(d, c.text), child: Text(t('सेव्ह', 'Save'))),
        ],
      ),
    );
    if (r == null) return;
    setState(() => s.customMsgs = r.split('\n').map((x) => x.trim()).where((x) => x.isNotEmpty).toList());
    save();
  }

  bool cloudBusy = false;

  Future<void> cloudLogin() async {
    setState(() => cloudBusy = true);
    final ok = await Cloud.signIn();
    if (!mounted) return;
    if (!ok) {
      setState(() => cloudBusy = false);
      toast(context, Cloud.lastError.isEmpty ? t('लॉगिन रद्द झालं', 'Sign-in cancelled') : Cloud.lastError);
      return;
    }
    try {
      final info = await Cloud.remoteInfo();
      if (!mounted) return;
      if (info != null) {
        final when = info[1].isEmpty ? '' : fmt(DateTime.parse(info[1]).toLocal(), 'd MMM yyyy, HH:mm');
        final choice = await showDialog<String>(
          context: context,
          builder: (d) => AlertDialog(
            title: Text(t('Drive वर आधीचा backup आहे', 'A backup exists on Drive')),
            content: Text(t('शेवटचा backup: $when\nकाय करायचं?', 'Last backup: $when\nWhat do you want to do?')),
            actions: [
              TextButton(onPressed: () => Navigator.pop(d, 'local'), child: Text(t('या फोनचा डेटा ठेवा', 'Keep this phone\'s data'))),
              FilledButton(onPressed: () => Navigator.pop(d, 'drive'), child: Text(t('Drive वरून आणा', 'Restore from Drive'))),
            ],
          ),
        );
        if (choice == 'drive') {
          await cloudRestore(ask: false);
        } else {
          await Cloud.upload();
        }
      } else {
        await Cloud.upload();
      }
    } catch (_) {}
    if (mounted) {
      setState(() => cloudBusy = false);
      toast(context, t('☁️ Google Drive जोडलं', '☁️ Google Drive connected'));
    }
  }

  Future<void> cloudBackup() async {
    setState(() => cloudBusy = true);
    final ok = await Cloud.upload();
    if (!mounted) return;
    setState(() => cloudBusy = false);
    toast(context, ok ? t('☁️ Backup झाला', '☁️ Backed up') : Cloud.lastError);
  }

  Future<void> cloudRestore({bool ask = true}) async {
    if (ask && !await confirm(context, t('या फोनचा सध्याचा डेटा बदलून Drive वरचा डेटा आणायचा?', "Replace this phone's data with the Drive backup?"), ok: t('हो, आणा', 'Yes, restore'))) return;
    setState(() => cloudBusy = true);
    try {
      final txt = await Cloud.download();
      if (!mounted) return;
      if (txt == null) {
        toast(context, t('Drive वर backup नाही', 'No backup on Drive'));
      } else {
        Cloud.applying = true;
        final ok = await Store.I.restore(txt);
        Cloud.applying = false;
        if (mounted) toast(context, ok ? t('♻️ Drive वरून डेटा आला', '♻️ Restored from Drive') : t('backup वाचता आला नाही', 'Could not read the backup'));
      }
    } catch (e) {
      Cloud.applying = false;
      if (mounted) toast(context, t('Drive वरून आणता आलं नाही', 'Could not restore from Drive'));
    }
    if (mounted) setState(() => cloudBusy = false);
  }

  Widget cloudSection() {
    final last = s.lastSync.isEmpty ? t('अजून नाही', 'not yet') : fmt(DateTime.parse(s.lastSync).toLocal(), 'd MMM, HH:mm');
    if (!Cloud.signedIn) {
      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(t('तुमचा डेटा तुमच्याच Google Drive मध्ये आपोआप सुरक्षित ठेवा. फोन बदलला तरी डेटा परत मिळेल.',
            'Keep your data safe in your own Google Drive automatically. Get it back even on a new phone.'), style: TextStyle(color: hint(context), fontSize: 13)),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: cloudBusy ? null : cloudLogin,
          icon: cloudBusy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.login),
          label: Text(t('Google ने लॉगिन करा', 'Sign in with Google')),
        ),
      ]);
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      ListTile(
        contentPadding: EdgeInsets.zero,
        leading: const CircleAvatar(backgroundColor: C.gold, child: Icon(Icons.cloud_done, color: Colors.white)),
        title: Text(Cloud.user?.email ?? s.cloudEmail),
        subtitle: Text('${t('शेवटचा backup', 'Last backup')}: $last'),
      ),
      SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(t('आपोआप backup (प्रत्येक बदलानंतर)', 'Auto backup (after every change)')),
          value: s.cloudOn,
          onChanged: (v) {
            setState(() => s.cloudOn = v);
            save();
          }),
      if (Cloud.lastError.isNotEmpty) Text('⚠️ ${Cloud.lastError}', style: TextStyle(color: redText(context), fontSize: 12)),
      const SizedBox(height: 6),
      Wrap(spacing: 8, runSpacing: 8, children: [
        FilledButton.icon(onPressed: cloudBusy ? null : cloudBackup, icon: const Icon(Icons.cloud_upload), label: Text(t('आता backup करा', 'Back up now'))),
        OutlinedButton.icon(onPressed: cloudBusy ? null : () => cloudRestore(), icon: const Icon(Icons.cloud_download), label: Text(t('Drive वरून परत आणा', 'Restore from Drive'))),
        TextButton(
            onPressed: cloudBusy
                ? null
                : () async {
                    await Cloud.signOut();
                    if (mounted) setState(() {});
                  },
            child: Text(t('लॉगआउट', 'Sign out'))),
      ]),
      if (cloudBusy) const Padding(padding: EdgeInsets.only(top: 8), child: LinearProgressIndicator()),
    ]);
  }

  Widget head(String tx) => Padding(
        padding: const EdgeInsets.only(top: 22, bottom: 6),
        child: Text(tx, style: TextStyle(fontWeight: FontWeight.w700, color: headColor(context))),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('⚙️ सेटिंग्स', '⚙️ Settings'))),
        body: ListView(padding: const EdgeInsets.fromLTRB(18, 0, 18, 40), children: [
          Center(
            child: CircleAvatar(
              radius: 34,
              backgroundColor: C.gold,
              child: Text(s.name.isEmpty ? '?' : s.name.characters.first, style: const TextStyle(fontSize: 28, color: Colors.white, fontWeight: FontWeight.w700)),
            ),
          ),
          head(t('👤 प्रोफाइल', '👤 Profile')),
          TextField(
              controller: name,
              decoration: InputDecoration(labelText: t('नाव', 'Name')),
              onChanged: (v) {
                if (v.trim().isEmpty) return;
                setState(() => s.name = v.trim());
                save();
              }),
          const SizedBox(height: 10),
          TextField(
              controller: company,
              decoration: InputDecoration(labelText: t('कंपनी / व्यवसाय', 'Company / business')),
              onChanged: (v) {
                s.company = v.trim();
                save();
              }),
          head(t('🌐 भाषा', '🌐 Language')),
          SegmentedButton<String>(
            segments: const [ButtonSegment(value: 'mr', label: Text('मराठी')), ButtonSegment(value: 'en', label: Text('English'))],
            selected: {s.lang},
            onSelectionChanged: (v) {
              setState(() {
                s.lang = v.first;
                s.aiLang = v.first;
              });
              Store.I.uiChanged();
            },
          ),
          head(t('🎨 दिसणं', '🎨 Appearance')),
          SegmentedButton<String>(
            segments: [
              ButtonSegment(value: 'system', label: Text(t('फोननुसार', 'System'))),
              ButtonSegment(value: 'light', label: Text(t('उजेड', 'Light'))),
              ButtonSegment(value: 'dark', label: Text(t('गडद', 'Dark'))),
            ],
            selected: {s.theme},
            onSelectionChanged: (v) {
              setState(() => s.theme = v.first);
              Store.I.uiChanged();
            },
          ),
          head(t('🔔 सूचना (Notifications)', '🔔 Notifications')),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(t('रिमाइंडर किती आधी', 'Remind me before')),
            trailing: DropdownButton<int>(
              value: s.remindBefore,
              items: [
                DropdownMenuItem(value: 0, child: Text(t('फक्त वेळेवर', 'Only on time'))),
                DropdownMenuItem(value: 5, child: Text(t('5 मिनिटं', '5 min'))),
                DropdownMenuItem(value: 15, child: Text(t('15 मिनिटं', '15 min'))),
                DropdownMenuItem(value: 30, child: Text(t('30 मिनिटं', '30 min'))),
                DropdownMenuItem(value: 60, child: Text(t('1 तास', '1 hour'))),
              ],
              onChanged: (v) {
                setState(() => s.remindBefore = v ?? 15);
                save(reschedule: true);
              },
            ),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(t('🌅 सकाळचा आढावा', '🌅 Morning summary')),
            subtitle: Text('${two(s.morningHour)}:00 — ${t('वेळ बदलायला ⏰ दाबा', 'tap ⏰ to change')}'),
            value: s.morningOn,
            onChanged: (v) {
              setState(() => s.morningOn = v);
              save(reschedule: true);
            },
            secondary: IconButton(icon: const Icon(Icons.schedule), onPressed: () => hourPick(s.morningHour, (h) => s.morningHour = h)),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(t('🌙 दिवसाचा शेवट रिमाइंडर', '🌙 End-of-day reminder')),
            subtitle: Text('${two(s.eodHour)}:00'),
            value: s.eodOn,
            onChanged: (v) {
              setState(() => s.eodOn = v);
              save(reschedule: true);
            },
            secondary: IconButton(icon: const Icon(Icons.schedule), onPressed: () => hourPick(s.eodHour, (h) => s.eodHour = h)),
          ),
          head(t('💬 सुरुवात', '💬 App start')),
          SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(t('🌍 सुरुवातीचं ॲनिमेशन', '🌍 Start animation')),
              value: s.splashOn,
              onChanged: (v) {
                setState(() => s.splashOn = v);
                save();
              }),
          SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(t('रोजचा मोटिवेशनल मेसेज', 'Daily motivational message')),
              subtitle: Text(todaysMessage(s.name, s.customMsgs)),
              value: s.motivationOn,
              onChanged: (v) {
                setState(() => s.motivationOn = v);
                save();
              }),
          ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(t('✏️ स्वतःचे मेसेज जोडा', '✏️ Add your own messages')),
              subtitle: Text(t('${s.customMsgs.length} जोडलेले', '${s.customMsgs.length} added')),
              onTap: editMsgs),
          head(t('✨ AI (मोफत Gemini)', '✨ AI (free Gemini)')),
          SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(t('AI चालू', 'AI on')),
              value: s.aiOn,
              onChanged: (v) {
                setState(() => s.aiOn = v);
                save();
              }),
          TextField(
            controller: key,
            obscureText: true,
            decoration: InputDecoration(
                labelText: 'Gemini API key',
                helperText: t('aistudio.google.com वरून मोफत मिळते. key फक्त या फोनमध्ये राहते.', 'Free from aistudio.google.com. The key stays only on this phone.')),
            onChanged: (v) {
              s.aiKey = v.trim();
              save();
            },
          ),
          const SizedBox(height: 10),
          TextField(
            controller: model,
            decoration: InputDecoration(labelText: t('मॉडेल नाव', 'Model name'), helperText: t('Default: gemini-flash-latest (error आला तरच बदला)', 'Default: gemini-flash-latest (change only on error)')),
            onChanged: (v) {
              s.aiModel = v.trim().isEmpty ? 'gemini-flash-latest' : v.trim();
              save();
            },
          ),
          const SizedBox(height: 10),
          AiButton(t('AI तपासा', 'Test AI'), busy: testing, onTap: test),
          const SizedBox(height: 10),
          Text(t('AI उत्तरांची भाषा', 'AI answer language')),
          const SizedBox(height: 6),
          SegmentedButton<String>(
            segments: [
              const ButtonSegment(value: 'mr', label: Text('मराठी')),
              const ButtonSegment(value: 'en', label: Text('English')),
              ButtonSegment(value: 'both', label: Text(t('दोन्ही', 'Both'))),
            ],
            selected: {s.aiLang},
            onSelectionChanged: (v) {
              setState(() => s.aiLang = v.first);
              save();
            },
          ),
          SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(t('🔒 PAN / खाते नंबर AI ला पाठवण्याआधी लपवा', '🔒 Hide PAN / account numbers before AI')),
              value: s.maskOn,
              onChanged: (v) {
                setState(() => s.maskOn = v);
                save();
              }),
          Text(t('⚠️ मोफत प्लॅनमध्ये पाठवलेला मजकूर Google वापरू शकतं. पासवर्ड, OTP, खाजगी तपशील AI ला पाठवू नका.',
                  "⚠️ On the free plan Google may use sent text. Don't send passwords, OTPs or private details to AI."),
              style: TextStyle(fontSize: 12, color: hint(context))),
          head(t('☁️ Google Drive backup', '☁️ Google Drive backup')),
          cloudSection(),
          head(t('🔒 सुरक्षा', '🔒 Security')),
          ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(t('App lock (PIN)', 'App lock (PIN)')),
              subtitle: Text(s.pin.isEmpty ? t('बंद', 'Off') : t('चालू', 'On')),
              onTap: setPin,
              trailing: const Icon(Icons.chevron_right)),
          head(t('💾 डेटा', '💾 Data')),
          ListTile(contentPadding: EdgeInsets.zero, title: Text(t('Backup घ्या', 'Take backup')), leading: const Icon(Icons.upload_file), onTap: () => backup(context)),
          ListTile(contentPadding: EdgeInsets.zero, title: Text(t('Backup परत आणा', 'Restore backup')), leading: const Icon(Icons.restore), onTap: () => restore(context)),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(Icons.delete_forever, color: redText(context)),
            title: Text(t('सगळा डेटा डिलीट करा', 'Delete all data'), style: TextStyle(color: redText(context))),
            onTap: () async {
              if (await confirm(context, t('सगळ्या नोंदी कायमच्या डिलीट होतील. आधी Backup घेतला का?', 'All entries will be deleted forever. Did you take a backup?'))) {
                Store.I.wipe();
                if (context.mounted) toast(context, t('डेटा डिलीट झाला', 'Data deleted'));
              }
            },
          ),
          head(t('ℹ️ अॅपबद्दल', 'ℹ️ About')),
          Text('Smart Diary v1.2\nby Smart Potli\nPowered by Smart World\nSmart World India Private Limited', style: TextStyle(color: hint(context), height: 1.5)),
          const SizedBox(height: 6),
          Text(t('तुमचा सगळा डेटा फक्त या फोनमध्ये राहतो. इंटरनेट फक्त AI साठी वापरलं जातं.', 'All your data stays on this phone. Internet is used only for AI.'),
              style: TextStyle(color: hint(context), fontSize: 12)),
        ]),
      );
}
