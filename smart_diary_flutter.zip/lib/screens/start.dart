import 'dart:math';
import 'package:flutter/material.dart';
import '../l10n.dart';
import '../store.dart';
import '../theme.dart';
import '../util.dart';
import 'home.dart';

class StartGate extends StatefulWidget {
  const StartGate({super.key});
  @override
  State<StartGate> createState() => _StartGateState();
}

class _StartGateState extends State<StartGate> {
  bool splashDone = false, unlocked = false;
  @override
  Widget build(BuildContext context) {
    final s = Store.I.s;
    if (s.name.isEmpty) return Onboarding(onDone: () => setState(() {}));
    if (s.splashOn && !splashDone) return Splash(onDone: () => setState(() => splashDone = true));
    if (s.pin.isNotEmpty && !unlocked) return LockScreen(onOk: () => setState(() => unlocked = true));
    return const HomeShell();
  }
}

class BrandFooter extends StatelessWidget {
  final Color color;
  const BrandFooter({super.key, this.color = Colors.white60});
  @override
  Widget build(BuildContext context) => Column(mainAxisSize: MainAxisSize.min, children: [
        Text('by Smart Potli', textAlign: TextAlign.center, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
        const SizedBox(height: 2),
        Text('Powered by Smart World', textAlign: TextAlign.center, style: TextStyle(color: color.withOpacity(.75), fontSize: 11)),
      ]);
}

class Onboarding extends StatefulWidget {
  final VoidCallback onDone;
  const Onboarding({super.key, required this.onDone});
  @override
  State<Onboarding> createState() => _OnboardingState();
}

class _OnboardingState extends State<Onboarding> {
  final name = TextEditingController(), company = TextEditingController();
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: ListView(padding: const EdgeInsets.all(28), children: [
            const SizedBox(height: 30),
            const Center(child: SizedBox(width: 110, height: 110, child: CustomPaint(painter: GlobePainter(rot: .6, glow: 1, dots: 1, scale: 1)))),
            const SizedBox(height: 14),
            Center(child: Text('Smart Diary', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w700, color: headColor(context)))),
            Center(child: BrandFooter(color: hint(context))),
            const SizedBox(height: 22),
            Center(
              child: SegmentedButton<String>(
                segments: const [ButtonSegment(value: 'mr', label: Text('मराठी')), ButtonSegment(value: 'en', label: Text('English'))],
                selected: {Store.I.s.lang},
                onSelectionChanged: (v) => setState(() {
                  Store.I.s.lang = v.first;
                  Store.I.s.aiLang = v.first;
                }),
              ),
            ),
            const SizedBox(height: 22),
            Text(t('तुमचं नाव काय?', 'What is your name?'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            TextField(controller: name, decoration: InputDecoration(hintText: t('उदा. सूरज', 'e.g. Suraj'))),
            const SizedBox(height: 14),
            TextField(controller: company, decoration: InputDecoration(hintText: t('कंपनी / व्यवसाय (optional)', 'Company / business (optional)'))),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: () {
                if (name.text.trim().isEmpty) return;
                Store.I.s.name = name.text.trim();
                Store.I.s.company = company.text.trim();
                Store.I.uiChanged();
                widget.onDone();
              },
              child: Text(t('सुरू करा 🚀', 'Start 🚀')),
            ),
            const SizedBox(height: 12),
            Text(t('नाव नंतर Settings मध्ये बदलता येईल. तुमचा सगळा डेटा फक्त या फोनमध्ये राहतो.', 'You can change the name later in Settings. All your data stays only on this phone.'),
                textAlign: TextAlign.center, style: TextStyle(color: hint(context), fontSize: 12)),
          ]),
        ),
      );
}

/// ~2.2 s: gold wire globe spins in, city dots light up and connect, then text. Tap to skip.
class Splash extends StatefulWidget {
  final VoidCallback onDone;
  const Splash({super.key, required this.onDone});
  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> with SingleTickerProviderStateMixin {
  late final AnimationController a = AnimationController(vsync: this, duration: const Duration(milliseconds: 2200));
  bool left = false;
  void finish() {
    if (left) return;
    left = true;
    widget.onDone();
  }

  @override
  void initState() {
    super.initState();
    a.forward().whenComplete(finish);
  }

  @override
  void dispose() {
    a.dispose();
    super.dispose();
  }

  double seg(double v, double from, double to) => ((v - from) / (to - from)).clamp(0.0, 1.0);

  @override
  Widget build(BuildContext context) {
    final s = Store.I.s;
    final msg = s.motivationOn ? todaysMessage(s.name, s.customMsgs) : '';
    return GestureDetector(
      onTap: finish,
      child: Scaffold(
        body: Container(
          width: double.infinity,
          decoration: const BoxDecoration(
            gradient: RadialGradient(center: Alignment(0, -.25), radius: 1.1, colors: [Color(0xFF285C4D), C.green, Color(0xFF0D261F)]),
          ),
          child: SafeArea(
            child: AnimatedBuilder(
              animation: a,
              builder: (_, __) {
                final v = a.value;
                final appear = Curves.easeOutBack.transform(seg(v, 0, .3));
                final dots = seg(v, .15, .6);
                final title = Curves.easeOut.transform(seg(v, .45, .65));
                final m = seg(v, .6, .78);
                return Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
                  const Spacer(flex: 3),
                  Center(
                    child: SizedBox(
                      width: 190,
                      height: 190,
                      child: CustomPaint(painter: GlobePainter(rot: v * pi * 1.2, glow: seg(v, .1, .5), dots: dots, scale: appear)),
                    ),
                  ),
                  const SizedBox(height: 26),
                  Opacity(
                    opacity: title,
                    child: Transform.translate(
                      offset: Offset(0, 10 * (1 - title)),
                      child: Column(children: [
                        const Text('Smart Diary', textAlign: TextAlign.center, style: TextStyle(color: C.gold, fontSize: 32, fontWeight: FontWeight.w700, letterSpacing: .5)),
                        const SizedBox(height: 6),
                        Text('${t('स्वागत आहे', 'Welcome')}, ${s.name}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 18)),
                      ]),
                    ),
                  ),
                  const SizedBox(height: 22),
                  if (msg.isNotEmpty)
                    Opacity(
                      opacity: m,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 36),
                        child: Text('“$msg”',
                            textAlign: TextAlign.center, style: const TextStyle(color: C.softGold, fontSize: 15, height: 1.45, fontStyle: FontStyle.italic)),
                      ),
                    ),
                  const Spacer(flex: 4),
                  Opacity(opacity: m, child: const BrandFooter()),
                  const SizedBox(height: 22),
                ]);
              },
            ),
          ),
        ),
      ),
    );
  }
}

/// Gold wireframe globe with glowing connected city dots.
class GlobePainter extends CustomPainter {
  final double rot, glow, dots, scale;
  const GlobePainter({required this.rot, required this.glow, required this.dots, required this.scale});

  static const _cities = [
    [19.0, 72.8], [28.6, 77.2], [51.5, -0.1], [40.7, -74.0], [35.7, 139.7], [1.3, 103.8], [25.2, 55.3], [-33.9, 151.2], [55.7, 37.6], [-23.5, -46.6],
  ];

  @override
  void paint(Canvas c, Size s) {
    final cx = s.width / 2, cy = s.height / 2;
    final r = min(s.width, s.height) / 2 * .82 * scale;
    if (r <= 0) return;
    final center = Offset(cx, cy);
    // glow
    c.drawCircle(center, r * 1.25, Paint()..shader = RadialGradient(colors: [C.gold.withOpacity(.28 * glow), Colors.transparent]).createShader(Rect.fromCircle(center: center, radius: r * 1.25)));
    // sphere body
    c.drawCircle(center, r, Paint()..shader = const RadialGradient(center: Alignment(-.35, -.35), colors: [Color(0xFF2F6B58), Color(0xFF123229)]).createShader(Rect.fromCircle(center: center, radius: r)));
    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = C.gold.withOpacity(.45);
    // latitudes
    for (final lat in [-60.0, -30.0, 0.0, 30.0, 60.0]) {
      final la = lat * pi / 180;
      final y = cy - r * sin(la);
      final w = r * cos(la);
      c.drawOval(Rect.fromCenter(center: Offset(cx, y), width: w * 2, height: w * .32), line);
    }
    // meridians (rotate)
    for (var k = 0; k < 6; k++) {
      final ang = rot + k * pi / 6;
      final w = (r * cos(ang)).abs();
      c.drawOval(Rect.fromCenter(center: center, width: w * 2, height: r * 2), line);
    }
    c.drawCircle(center, r, line
      ..color = C.gold.withOpacity(.85)
      ..strokeWidth = 1.6);
    // city dots
    final pts = <Offset>[];
    final n = (dots * _cities.length).floor();
    for (var i = 0; i < _cities.length; i++) {
      final la = _cities[i][0] * pi / 180, lo = _cities[i][1] * pi / 180 + rot;
      if (cos(lo) * cos(la) < -.05) continue; // back side
      final p = Offset(cx + r * cos(la) * sin(lo), cy - r * sin(la));
      if (i < n) {
        pts.add(p);
        c.drawCircle(p, 5, Paint()..color = const Color(0x66FFE9A6));
        c.drawCircle(p, 2.4, Paint()..color = const Color(0xFFFFE9A6));
      }
    }
    final arc = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3
      ..color = const Color(0xCCFFE9A6);
    for (var i = 1; i < pts.length; i++) {
      final a = pts[i - 1], b = pts[i];
      final mid = Offset((a.dx + b.dx) / 2, (a.dy + b.dy) / 2);
      final out = (mid - center);
      final ctrl = mid + out * .35;
      c.drawPath(Path()
        ..moveTo(a.dx, a.dy)
        ..quadraticBezierTo(ctrl.dx, ctrl.dy, b.dx, b.dy), arc);
    }
  }

  @override
  bool shouldRepaint(GlobePainter o) => o.rot != rot || o.glow != glow || o.dots != dots || o.scale != scale;
}

class LockScreen extends StatefulWidget {
  final VoidCallback onOk;
  const LockScreen({super.key, required this.onOk});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  String entered = '';
  bool wrong = false;
  void tap(String d) {
    if (entered.length >= 4) return;
    setState(() {
      entered += d;
      wrong = false;
    });
    if (entered.length == 4) {
      if (entered == Store.I.s.pin) {
        widget.onOk();
      } else {
        setState(() {
          wrong = true;
          entered = '';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final pr = Theme.of(context).colorScheme.primary;
    Widget key(String d) => Padding(
          padding: const EdgeInsets.all(8),
          child: SizedBox(
            width: 72,
            height: 72,
            child: OutlinedButton(
              style: OutlinedButton.styleFrom(shape: const CircleBorder()),
              onPressed: d.isEmpty
                  ? null
                  : () {
                      if (d == '⌫') {
                        setState(() => entered = entered.isEmpty ? '' : entered.substring(0, entered.length - 1));
                      } else {
                        tap(d);
                      }
                    },
              child: Text(d, style: const TextStyle(fontSize: 22)),
            ),
          ),
        );
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('🔒', style: TextStyle(fontSize: 44)),
            const SizedBox(height: 8),
            Text('Smart Diary', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700, color: headColor(context))),
            const SizedBox(height: 18),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(
                  4,
                  (i) => Container(
                        margin: const EdgeInsets.all(8),
                        width: 16,
                        height: 16,
                        decoration: BoxDecoration(shape: BoxShape.circle, color: i < entered.length ? pr : hint(context).withOpacity(.35)),
                      )),
            ),
            SizedBox(height: 24, child: wrong ? Text(t('चुकीचा PIN', 'Wrong PIN'), style: TextStyle(color: redText(context))) : null),
            for (final row in [
              ['1', '2', '3'],
              ['4', '5', '6'],
              ['7', '8', '9'],
              ['', '0', '⌫']
            ])
              Row(mainAxisSize: MainAxisSize.min, children: row.map(key).toList()),
          ]),
        ),
      ),
    );
  }
}
