import 'package:flutter/material.dart';
import '../ai.dart';
import '../l10n.dart';
import '../models.dart';
import '../store.dart';
import '../util.dart';
import '../widgets.dart';

class SummaryPage extends StatefulWidget {
  final String? person, text;
  const SummaryPage({super.key, this.person, this.text});
  @override
  State<SummaryPage> createState() => _SummaryPageState();
}

class _SummaryPageState extends State<SummaryPage> {
  late final person = TextEditingController(text: widget.person ?? '');
  late final input = TextEditingController(text: widget.text ?? '');
  final out = TextEditingController();
  String format = 'minutes';
  late String lang = Store.I.s.aiLang;
  late bool mask = Store.I.s.maskOn;
  bool busy = false, shown = false;

  String cleanInput() => mask ? maskSensitive(input.text.trim()) : input.text.trim();

  Future<void> run(String prompt) async {
    setState(() {
      busy = true;
      shown = true;
      out.text = t('✨ विचार करतोय…', '✨ Thinking…');
    });
    try {
      out.text = await AI.ask(prompt);
    } catch (e) {
      out.text = e.toString();
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> make() async {
    if (input.text.trim().isEmpty) {
      toast(context, t('आधी चर्चा लिहा किंवा पेस्ट करा', 'First type or paste the discussion'));
      return;
    }
    final fm = {
      'minutes': 'Minutes of Meeting: 1) मुख्य चर्चा 2) काय ठरलं 3) Action items (कोण, काय, deadline)',
      'wa': 'WhatsApp वर पाठवण्यासाठी 4-5 ओळींचा छोटा, नम्र मेसेज',
      'email': 'Formal business email, Subject line सोबत',
    }[format];
    final p = person.text.trim();
    await run('${AI.header()}\nखाली ${p.isEmpty ? 'एका व्यक्ती' : p}सोबत झालेल्या business चर्चेचा मजकूर आहे. त्याचा $fm बनव, ${AI.langFor(lang)}. '
        'फक्त दिलेल्या माहितीवरूनच लिही, काही नवीन जोडू नको.\n\n${cleanInput()}');
  }

  Future<void> toTasks() async {
    setState(() => busy = true);
    try {
      final j = await AI.askJson('आज ${todayKey()}. या मजकुरातून Action items काढ. फक्त JSON array दे: [{"title":"छोटं काम","date":"YYYY-MM-DD किंवा null"}]. '
          'title ${AI.langFor(lang)} लिही. काही नसेल तर [].\n\n${out.text.isNotEmpty ? out.text : cleanInput()}');
      final st = Store.I;
      var n = 0;
      if (j is List) {
        for (final x in j) {
          if (x is! Map) continue;
          final tl = (x['title'] ?? '').toString();
          if (tl.isEmpty) continue;
          final d = (x['date'] ?? '').toString();
          st.items.add(Item(
              id: st.newId(), type: 'task', title: tl, date: RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(d) ? d : todayKey(), person: person.text.trim()));
          n++;
        }
      }
      st.save();
      if (mounted) toast(context, n > 0 ? t('✅ $n कामं ॲड झाली', '✅ $n tasks added') : t('कामं सापडली नाहीत', 'No tasks found'));
    } catch (e) {
      if (mounted) toast(context, e is AiError ? e.msg : t('कामं काढता आली नाहीत', 'Could not extract tasks'));
    }
    if (mounted) setState(() => busy = false);
  }

  void saveNote() {
    final v = out.text.trim();
    if (v.isEmpty) return;
    final st = Store.I, p = person.text.trim();
    st.upsertContact(p, '');
    st.add(Item(
        id: st.newId(), type: 'note', kind: 'summary', title: p.isEmpty ? t('सारांश', 'Summary') : p, person: p, content: v, date: todayKey(),
        tags: [t('सारांश', 'Summary')]));
    toast(context, t('💾 Notes मध्ये सेव्ह', '💾 Saved to Notes'));
  }

  void compare() {
    final p = person.text.trim();
    final old = Store.I.items.where((e) => e.kind == 'summary' && e.person == p).toList();
    final last = old.length > 2 ? old.sublist(old.length - 2) : old;
    run('${AI.header()}\n$p सोबतच्या मागच्या चर्चा:\n${last.map((e) => '${nice(e.date)}:\n${e.content}').join('\n\n')}\n\nआजची चर्चा:\n${out.text}\n\n'
        '${AI.langFor(lang)} सांग: मागच्या वेळी काय ठरलं होतं, त्यातलं काय पूर्ण झालं, काय अजून बाकी आहे.');
  }

  @override
  Widget build(BuildContext context) {
    final p = person.text.trim();
    final hasOld = p.isNotEmpty && Store.I.items.any((e) => e.kind == 'summary' && e.person == p);
    return Scaffold(
      appBar: AppBar(title: Text(t('📋 चर्चेचा सारांश', '📋 Discussion summary'))),
      body: ListView(padding: const EdgeInsets.fromLTRB(18, 0, 18, 40), children: [
        TextField(
            controller: person,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(labelText: t('कोणासोबत चर्चा', 'Discussion with'), hintText: t('उदा. CA', 'e.g. CA'))),
        if (Store.I.contacts.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Wrap(spacing: 6, runSpacing: 6, children: [
              for (final c in Store.I.contacts.take(8)) ActionChip(label: Text(c.name), onPressed: () => setState(() => person.text = c.name)),
            ]),
          ),
        const SizedBox(height: 12),
        TextField(
            controller: input,
            maxLines: null,
            minLines: 6,
            decoration: InputDecoration(
                hintText: t('बोलणं झालेले मुद्दे लिहा, किंवा WhatsApp/Email chat कॉपी करून इथे पेस्ट करा… (🎤 कीबोर्ड माइकनेही चालेल)',
                    'Type the discussion points, or copy-paste a WhatsApp/Email chat here… (keyboard 🎤 works too)'))),
        Section(t('फॉरमॅट', 'Format')),
        Wrap(spacing: 8, runSpacing: 6, children: [
          for (final f in [['minutes', 'Minutes'], ['wa', t('WhatsApp छोटा', 'Short WhatsApp')], ['email', 'Formal Email']])
            ChoiceChip(label: Text(f[1]), selected: format == f[0], onSelected: (_) => setState(() => format = f[0])),
        ]),
        Section(t('भाषा', 'Language')),
        Wrap(spacing: 8, runSpacing: 6, children: [
          for (final f in [['mr', 'मराठी'], ['en', 'English'], ['both', t('दोन्ही', 'Both')]])
            ChoiceChip(label: Text(f[1]), selected: lang == f[0], onSelected: (_) => setState(() => lang = f[0])),
        ]),
        SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: mask,
            onChanged: (v) => setState(() => mask = v),
            title: Text(t('🔒 PAN, खाते नंबर AI ला पाठवण्याआधी लपवा', '🔒 Hide PAN / account numbers before sending to AI')),
            subtitle: Text(t('उदा. XXXX1234', 'e.g. XXXX1234'))),
        if (!AI.ready)
          Card(child: ListTile(leading: const Text('✨'), title: Text(t('AI साठी Settings मध्ये मोफत Gemini key टाका', 'Add a free Gemini key in Settings for AI'))))
        else
          AiButton(t('✨ सारांश बनवा', '✨ Make summary'), busy: busy, onTap: make),
        if (shown) ...[
          Section(t('सारांश', 'Summary')),
          ResultBox(ctrl: out, subject: '${t('चर्चा सारांश', 'Discussion summary')}${p.isNotEmpty ? ' — $p' : ''}'),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: FilledButton(onPressed: busy ? null : toTasks, child: Text(t('✅ कामं ॲड करा', '✅ Add as tasks')))),
            const SizedBox(width: 8),
            Expanded(child: FilledButton.tonal(onPressed: busy ? null : saveNote, child: Text(t('💾 सेव्ह करा', '💾 Save')))),
          ]),
          if (hasOld) TextButton(onPressed: busy ? null : compare, child: Text(t('🔁 मागच्या चर्चेशी तुलना', '🔁 Compare with earlier talks'))),
        ],
        const SizedBox(height: 10),
        Text(t('⚠️ मोफत प्लॅनमध्ये पाठवलेला मजकूर Google वापरू शकतं. पासवर्ड, OTP पाठवू नका.', "⚠️ On the free plan Google may use sent text. Don't send passwords or OTPs."),
            style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
      ]),
    );
  }
}

class AskAiPage extends StatefulWidget {
  final String? prefill;
  const AskAiPage({super.key, this.prefill});
  @override
  State<AskAiPage> createState() => _AskAiPageState();
}

class _AskAiPageState extends State<AskAiPage> {
  late final q = TextEditingController(text: widget.prefill ?? '');
  final out = TextEditingController();
  bool busy = false, shown = false;

  Future<void> ask() async {
    if (q.text.trim().isEmpty) return;
    setState(() {
      busy = true;
      shown = true;
      out.text = t('✨ विचार करतोय…', '✨ Thinking…');
    });
    try {
      out.text = await AI.ask('${AI.header()}\nखालच्या नोंदींवरूनच ${AI.lang()} थोडक्यात उत्तर दे; माहिती नसेल तर तसं सांग.\n\n'
          '${AI.clean(AI.context())}\n\nप्रश्न: ${AI.clean(q.text.trim())}');
    } catch (e) {
      out.text = e.toString();
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> addEntry() async {
    if (q.text.trim().isEmpty) return;
    setState(() => busy = true);
    try {
      final j = await AI.askJson('आज ${todayKey()}, वेळ ${nowHM()}. या वाक्यावरून डायरी नोंद काढ. फक्त JSON: '
          '{"type":"meeting" किंवा "task","title":"छोटं नाव","date":"YYYY-MM-DD","time":"HH:MM किंवा null","person":"व्यक्ती किंवा रिकामं"}\nवाक्य: ${q.text.trim()}');
      if (j is! Map) throw AiError(t('नीट समजलं नाही, परत लिहून बघा.', "Didn't understand, please rephrase."));
      final st = Store.I;
      final type = j['type'] == 'meeting' ? 'meeting' : 'task';
      final d = (j['date'] ?? '').toString(), tm = (j['time'] ?? '').toString(), p = (j['person'] ?? '').toString();
      final e = Item(
        id: st.newId(),
        type: type,
        title: (j['title'] ?? q.text).toString(),
        date: RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(d) ? d : todayKey(),
        time: RegExp(r'^\d{2}:\d{2}$').hasMatch(tm) ? tm : null,
        person: p,
        phone: st.contact(p)?.phone ?? '',
      );
      st.add(e);
      if (!mounted) return;
      toast(context, '✨ ${type == 'meeting' ? t('मीटिंग', 'Meeting') : t('काम', 'Task')} — ${dayLabel(e.date)}${e.time != null ? ' ${e.time}' : ''}');
      Navigator.pop(context);
      return;
    } catch (e) {
      if (mounted) toast(context, e is AiError ? e.msg : t('नीट समजलं नाही, परत लिहून बघा.', "Didn't understand, please rephrase."));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(t('✨ AI ला विचारा', '✨ Ask AI'))),
        body: ListView(padding: const EdgeInsets.all(18), children: [
          TextField(
              controller: q,
              autofocus: true,
              maxLines: null,
              minLines: 3,
              decoration: InputDecoration(
                  hintText: t('उदा. CA सोबत काय बाकी आहे?\nकिंवा: उद्या 5 ला राहुलसोबत मीटिंग', "e.g. What's pending with CA?\nor: meeting with Rahul tomorrow 5 pm"))),
          const SizedBox(height: 10),
          if (!AI.ready)
            Card(child: ListTile(leading: const Text('✨'), title: Text(t('Settings मध्ये मोफत Gemini key टाका', 'Add a free Gemini key in Settings'))))
          else
            Row(children: [
              Expanded(child: AiButton(t('विचारा', 'Ask'), busy: busy, onTap: ask)),
              const SizedBox(width: 8),
              Expanded(child: FilledButton(onPressed: busy ? null : addEntry, child: Text(t('✨ नोंद बनवा', '✨ Create entry')))),
            ]),
          if (shown) ResultBox(ctrl: out, subject: t('AI उत्तर', 'AI answer')),
        ]),
      );
}
