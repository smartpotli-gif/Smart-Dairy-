import 'package:flutter/material.dart';
import '../ai.dart';
import '../l10n.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../util.dart';
import '../widgets.dart';
import 'people.dart';

class _Tag extends StatelessWidget {
  final String tx;
  const _Tag(this.tx);
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
        decoration: BoxDecoration(color: isDark(context) ? const Color(0xFF3A3215) : C.softGold.withOpacity(.7), borderRadius: BorderRadius.circular(10)),
        child: Text('#$tx', style: TextStyle(fontSize: 11, color: isDark(context) ? C.softGold : const Color(0xFF3A2F05))),
      );
}

class NoteTile extends StatelessWidget {
  final Item e;
  final bool showDate;
  const NoteTile(this.e, {super.key, this.showDate = false});
  @override
  Widget build(BuildContext context) {
    final head = e.title.isNotEmpty ? e.title : (e.kind == 'summary' ? t('सारांश', 'Summary') : '');
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NoteViewPage(id: e.id))),
        child: Padding(
          padding: const EdgeInsets.all(13),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (head.isNotEmpty || showDate)
                  Row(children: [
                    if (head.isNotEmpty)
                      Flexible(child: Text(head, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w700, color: headColor(context)))),
                    if (showDate) Text('  ${nice(e.date)}', style: TextStyle(fontSize: 12, color: hint(context))),
                  ]),
                Text(e.content, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14.5)),
                if (e.tags.isNotEmpty)
                  Padding(padding: const EdgeInsets.only(top: 6), child: Wrap(spacing: 4, runSpacing: 4, children: e.tags.map((x) => _Tag(x)).toList())),
              ]),
            ),
            if (e.pinned) const Text('📌'),
          ]),
        ),
      ),
    );
  }
}

class NotesTab extends StatefulWidget {
  const NotesTab({super.key});
  @override
  State<NotesTab> createState() => _NotesTabState();
}

class _NotesTabState extends State<NotesTab> {
  String q = '', tag = '', subject = '';
  final Set<String> open = {};
  bool init = false;
  final keys = <String, GlobalKey>{};
  final ai = TextEditingController();
  bool aiBusy = false, aiShow = false;

  Future<void> jump() async {
    final d = await pickDate(context, todayKey());
    if (d == null) return;
    setState(() => open.add(d));
    await Future.delayed(const Duration(milliseconds: 80));
    final k = keys[d];
    if (k?.currentContext != null) {
      Scrollable.ensureVisible(k!.currentContext!, duration: const Duration(milliseconds: 350));
    } else if (mounted) {
      toast(context, t('${nice(d)} ला नोट्स नाहीत', 'No notes on ${nice(d)}'));
    }
  }

  Future<void> runAi(List<Item> l, String what) async {
    if (l.isEmpty) {
      toast(context, t('नोट्स नाहीत', 'No notes'));
      return;
    }
    setState(() {
      aiBusy = true;
      aiShow = true;
      ai.text = t('✨ विचार करतोय…', '✨ Thinking…');
    });
    try {
      ai.text = await AI.ask('${AI.header()}\n$what ${AI.lang()} छोटा सारांश दे: मुख्य गोष्टी, ठरलेले निर्णय, बाकी कामं.\n\n'
          '${AI.clean(l.map((e) => '${e.date}${e.title.isNotEmpty ? ' [${e.title}]' : ''}: ${e.content}').join('\n\n'))}');
    } catch (e) {
      ai.text = e.toString();
    }
    if (mounted) setState(() => aiBusy = false);
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) {
          final st = Store.I;
          final all = st.notes;
          final subjects = st.subjects;
          final tags = {for (final e in all) ...e.tags}.toList();
          final list = all.where((e) {
            if (subject.isNotEmpty && e.title.trim() != subject) return false;
            if (tag.isNotEmpty && !e.tags.contains(tag)) return false;
            if (q.isEmpty) return true;
            return '${e.title} ${e.content} ${e.tags.join(' ')} ${e.person}'.toLowerCase().contains(q.toLowerCase());
          }).toList();
          final pins = list.where((e) => e.pinned).toList();
          final rest = list.where((e) => !e.pinned).toList();
          final days = rest.map((e) => e.date).toSet().toList()..sort((a, b) => b.compareTo(a));
          if (!init) {
            open.addAll(days.take(2));
            init = true;
          }
          final searching = q.isNotEmpty || tag.isNotEmpty || subject.isNotEmpty;
          return Scaffold(
            floatingActionButton: FloatingActionButton.extended(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NoteEditPage(subject: subject.isEmpty ? null : subject))),
              icon: const Icon(Icons.add),
              label: Text(subject.isEmpty ? t('नोट', 'Note') : t('आजची नोंद', "Today's entry")),
            ),
            body: ListView(padding: const EdgeInsets.fromLTRB(18, 4, 18, 90), children: [
              Row(children: [
                Expanded(child: TextField(onChanged: (v) => setState(() => q = v), decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: t('शोधा…', 'Search…')))),
                IconButton(tooltip: t('तारखेवर जा', 'Go to date'), onPressed: jump, icon: const Icon(Icons.event)),
              ]),
              if (subjects.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(t('विषय', 'Subjects'), style: TextStyle(fontSize: 12, color: hint(context))),
                SizedBox(
                  height: 42,
                  child: ListView(scrollDirection: Axis.horizontal, children: [
                    for (final sj in subjects)
                      Padding(
                        padding: const EdgeInsets.only(right: 6, top: 4),
                        child: ChoiceChip(
                            label: Text(sj),
                            selected: subject == sj,
                            onSelected: (_) => setState(() {
                                  subject = subject == sj ? '' : sj;
                                  aiShow = false;
                                })),
                      ),
                  ]),
                ),
              ],
              if (tags.isNotEmpty)
                SizedBox(
                  height: 42,
                  child: ListView(scrollDirection: Axis.horizontal, children: [
                    for (final tg in tags)
                      Padding(
                        padding: const EdgeInsets.only(right: 6, top: 4),
                        child: FilterChip(label: Text('#$tg'), selected: tag == tg, onSelected: (_) => setState(() => tag = tag == tg ? '' : tg)),
                      ),
                  ]),
                ),
              if (subject.isNotEmpty) ...[
                Section('📂 $subject (${list.length})'),
                if (AI.ready) AiButton(t('✨ $subject सोबत आतापर्यंत काय झालं', '✨ Everything so far with $subject'), busy: aiBusy, onTap: () => runAi(list, '"$subject" विषयावरच्या सगळ्या नोंदींचा')),
              ] else if (AI.ready && !searching) ...[
                const SizedBox(height: 10),
                AiButton(t('✨ या आठवड्याचा सारांश', "✨ This week's summary"),
                    busy: aiBusy, onTap: () => runAi(all.where((e) => e.date.compareTo(daysFrom(-7)) >= 0).toList(), 'या आठवड्याच्या माझ्या business नोट्सचा')),
              ],
              if (aiShow) ResultBox(ctrl: ai, subject: subject.isEmpty ? t('आठवड्याचा सारांश', 'Weekly summary') : subject),
              if (pins.isNotEmpty) ...[Section(t('📌 Pin केलेल्या', '📌 Pinned')), ...pins.map((e) => NoteTile(e, showDate: true))],
              for (final d in days) ...[
                InkWell(
                  key: keys.putIfAbsent(d, () => GlobalKey()),
                  onTap: () => setState(() => open.contains(d) ? open.remove(d) : open.add(d)),
                  child: Container(
                    margin: const EdgeInsets.only(top: 14, bottom: 8),
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Theme.of(context).dividerColor))),
                    child: Row(children: [
                      Icon(searching || open.contains(d) ? Icons.expand_more : Icons.chevron_right, color: headColor(context)),
                      Text(dayLabel(d), style: TextStyle(fontWeight: FontWeight.w700, color: headColor(context), fontSize: 15)),
                      if (dayLabel(d) != nice(d)) Text('  ${nice(d)}', style: TextStyle(color: hint(context), fontSize: 12)),
                      const Spacer(),
                      Text('${rest.where((e) => e.date == d).length} ${t('नोट्स', 'notes')}', style: TextStyle(color: hint(context), fontSize: 12)),
                    ]),
                  ),
                ),
                if (searching || open.contains(d)) ...rest.where((e) => e.date == d).map((e) => NoteTile(e)),
              ],
              if (list.isEmpty) Empty(t('काही सापडलं नाही.', 'Nothing found.')),
            ]),
          );
        },
      );
}

class NoteViewPage extends StatefulWidget {
  final int id;
  const NoteViewPage({super.key, required this.id});
  @override
  State<NoteViewPage> createState() => _NoteViewPageState();
}

class _NoteViewPageState extends State<NoteViewPage> {
  final ai = TextEditingController();
  bool busy = false, show = false;
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: Store.I,
        builder: (context, _) {
          final e = Store.I.byId(widget.id);
          if (e == null) return Scaffold(appBar: AppBar(), body: Center(child: Text(t('नोट डिलीट झाली.', 'Note deleted.'))));
          final lines = e.content.split('\n');
          final pr = Theme.of(context).colorScheme.primary;
          return Scaffold(
            appBar: AppBar(title: Text('${dayLabel(e.date)} · ${nice(e.date)}'), actions: [
              IconButton(
                  icon: Icon(e.pinned ? Icons.push_pin : Icons.push_pin_outlined),
                  onPressed: () {
                    e.pinned = !e.pinned;
                    Store.I.save(reschedule: false);
                  }),
              IconButton(icon: const Icon(Icons.edit), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => NoteEditPage(edit: e)))),
              IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    if (await deleteItem(context, e) && context.mounted) Navigator.pop(context);
                  }),
            ]),
            body: ListView(padding: const EdgeInsets.fromLTRB(18, 0, 18, 40), children: [
              if (e.title.isNotEmpty) Text(e.title, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: headColor(context))),
              if (e.person.isNotEmpty)
                InkWell(
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PersonPage(name: e.person))),
                  child: Padding(padding: const EdgeInsets.only(top: 4), child: Text('👤 ${e.person}', style: const TextStyle(color: C.gold, fontWeight: FontWeight.w600))),
                ),
              const SizedBox(height: 10),
              for (var i = 0; i < lines.length; i++)
                if (lines[i].startsWith('☐') || lines[i].startsWith('☑'))
                  InkWell(
                    onTap: () {
                      final l = e.content.split('\n');
                      l[i] = (l[i].startsWith('☐') ? '☑' : '☐') + l[i].substring(1);
                      e.content = l.join('\n');
                      Store.I.save(reschedule: false);
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(children: [
                        Icon(lines[i].startsWith('☑') ? Icons.check_box : Icons.check_box_outline_blank, color: pr),
                        const SizedBox(width: 10),
                        Expanded(
                            child: Text(lines[i].substring(1).trim(),
                                style: TextStyle(fontSize: 16, decoration: lines[i].startsWith('☑') ? TextDecoration.lineThrough : null))),
                      ]),
                    ),
                  )
                else
                  SelectableText(lines[i].isEmpty ? ' ' : lines[i], style: const TextStyle(fontSize: 16, height: 1.5)),
              if (e.tags.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12), child: Wrap(spacing: 6, runSpacing: 6, children: e.tags.map((x) => _Tag(x)).toList())),
              const SizedBox(height: 16),
              ShareBar(text: () => '${e.title.isNotEmpty ? '${e.title}\n' : ''}${e.content}', subject: e.title.isNotEmpty ? e.title : 'Note — ${nice(e.date)}'),
              if (AI.ready) ...[
                const SizedBox(height: 14),
                AiButton(t('✨ मुख्य मुद्दे', '✨ Key points'), busy: busy, onTap: () async {
                  setState(() {
                    busy = true;
                    show = true;
                    ai.text = t('✨ विचार करतोय…', '✨ Thinking…');
                  });
                  try {
                    ai.text = await AI.ask('${AI.header()}\nया नोटचे मुख्य मुद्दे ${AI.lang()} 3-5 ओळींत दे:\n\n${AI.clean(e.content)}');
                  } catch (err) {
                    ai.text = err.toString();
                  }
                  if (mounted) setState(() => busy = false);
                }),
                if (show) ResultBox(ctrl: ai, subject: t('मुख्य मुद्दे', 'Key points')),
              ],
            ]),
          );
        },
      );
}

class NoteEditPage extends StatefulWidget {
  final Item? edit;
  final String? prefill, subject;
  const NoteEditPage({super.key, this.edit, this.prefill, this.subject});
  @override
  State<NoteEditPage> createState() => _NoteEditPageState();
}

class _NoteEditPageState extends State<NoteEditPage> {
  late final subj = TextEditingController(text: widget.edit?.title ?? widget.subject ?? '');
  late final text = TextEditingController(text: widget.edit?.content ?? widget.prefill ?? '');
  late final tags = TextEditingController(text: widget.edit?.tags.join(', ') ?? '');
  late String date = widget.edit?.date ?? todayKey();

  void addCheck() {
    final tx = text.text;
    text.text = '$tx${tx.isEmpty || tx.endsWith('\n') ? '' : '\n'}☐ ';
    text.selection = TextSelection.collapsed(offset: text.text.length);
  }

  void save() {
    final v = text.text.trim();
    if (v.isEmpty) {
      Navigator.pop(context);
      return;
    }
    final tg = tags.text.split(',').map((x) => x.trim()).where((x) => x.isNotEmpty).toList();
    final st = Store.I;
    if (widget.edit != null) {
      widget.edit!
        ..title = subj.text.trim()
        ..content = v
        ..tags = tg
        ..date = date;
      st.save(reschedule: false);
    } else {
      st.add(Item(id: st.newId(), type: 'note', title: subj.text.trim(), content: v, tags: tg, date: date));
    }
    toast(context, t('📝 नोट सेव्ह', '📝 Note saved'));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final subjects = Store.I.subjects;
    return Scaffold(
      appBar: AppBar(title: Text(widget.edit == null ? t('📝 नवीन नोट', '📝 New note') : t('✏️ नोट बदला', '✏️ Edit note')), actions: [
        TextButton(onPressed: save, child: Text(t('सेव्ह', 'Save'), style: const TextStyle(fontWeight: FontWeight.w700))),
      ]),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        TextField(
          controller: subj,
          autofocus: widget.edit == null && widget.subject == null,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
          decoration: InputDecoration(labelText: t('विषय (Subject)', 'Subject'), hintText: t('उदा. CA', 'e.g. CA')),
          onChanged: (_) => setState(() {}),
        ),
        if (subjects.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Wrap(spacing: 6, runSpacing: 6, children: [
              for (final sj in subjects.where((x) => subj.text.isEmpty || x.toLowerCase().contains(subj.text.toLowerCase())).take(8))
                ActionChip(label: Text(sj), onPressed: () => setState(() => subj.text = sj)),
            ]),
          ),
        const SizedBox(height: 12),
        TextField(
            controller: text,
            autofocus: widget.edit == null && widget.subject != null,
            maxLines: null,
            minLines: 10,
            decoration: InputDecoration(hintText: t('काय बोलणं झालं, काय ठरलं… (कीबोर्डवरचा 🎤 वापरून बोलूनही लिहा)', 'What was discussed, what was decided… (use the keyboard 🎤 to dictate)'))),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 6, children: [
          ActionChip(avatar: const Text('☐'), label: Text(t('Checklist ओळ', 'Checklist line')), onPressed: addCheck),
          ActionChip(
              avatar: const Icon(Icons.event, size: 18),
              label: Text(nice(date)),
              onPressed: () async {
                final d = await pickDate(context, date);
                if (d != null) setState(() => date = d);
              }),
        ]),
        const SizedBox(height: 12),
        TextField(controller: tags, decoration: InputDecoration(labelText: t('Tags (स्वल्पविरामाने)', 'Tags (comma separated)'), hintText: t('उदा. काम, CEO', 'e.g. work, CEO'))),
        const SizedBox(height: 20),
        FilledButton(onPressed: save, child: Text(t('सेव्ह करा', 'Save'))),
      ]),
    );
  }
}
