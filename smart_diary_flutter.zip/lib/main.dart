import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'notifications.dart';
import 'store.dart';
import 'theme.dart';
import 'screens/start.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('mr');
  await initializeDateFormatting('en');
  await Store.I.load();
  await Notif.init();
  Store.I.save();
  runApp(const SmartDiaryApp());
}

class SmartDiaryApp extends StatefulWidget {
  const SmartDiaryApp({super.key});
  @override
  State<SmartDiaryApp> createState() => _SmartDiaryAppState();
}

class _SmartDiaryAppState extends State<SmartDiaryApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      Store.I.flush();
    } else if (state == AppLifecycleState.resumed) {
      Store.I.materialize();
      Store.I.save();
    }
  }

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<int>(
        valueListenable: Store.I.ui,
        builder: (_, __, ___) {
          final th = Store.I.s.theme;
          return MaterialApp(
            title: 'Smart Diary',
            debugShowCheckedModeBanner: false,
            theme: buildTheme(Brightness.light),
            darkTheme: buildTheme(Brightness.dark),
            themeMode: th == 'dark' ? ThemeMode.dark : th == 'light' ? ThemeMode.light : ThemeMode.system,
            home: const StartGate(),
          );
        },
      );
}
