import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'l10n.dart';
import 'models.dart';
import 'store.dart';
import 'theme.dart';
import 'util.dart';
import 'screens/meeting.dart';
import 'screens/trip.dart';
import 'screens/forms.dart';

void toast(BuildContext c, String m, {String? action, VoidCallback? onAction}) {
  ScaffoldMessenger.of(c)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(m),
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 3),
      action: action == null ? null : SnackBarAction(label: action, onPressed: onAction ?? () {}),
    ));
}

Future<void> copyText(BuildContext c, String tx) async {
  await Clipboard.setData(ClipboardData(text: tx));
  if (c.mounted) toast(c, t('📋 कॉपी झालं', '📋 Copied'));
}

Future<void> openUrl(BuildContext c, String url) async {
  bool ok = false;
  try {
    ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  } catch (_) {}
  if (!ok && c.mounted) toast(c, t('उघडता आलं नाही', 'Could not open'));
}

Future<void> openWhatsApp(BuildContext c, String phone, String text) =>
    openUrl(c, 'https://wa.me/${waNumber(phone)}?text=${Uri.encodeComponent(text)}');

Future<void> openEmail(BuildContext c, String subject, String body) =>
    openUrl(c, 'mailto:?subject=${Uri.encodeComponent(subject)}&body=${Uri.encodeComponent(body)}');

Future<String?> pickDate(BuildContext c, String initial) async {
  final d = await showDatePicker(
      context: c, initialDate: parseKey(initial) ?? DateTime.now(), firstDate: DateTime(2020), lastDate: DateTime(2100));
  return d == null ? null : dkey(d);
}

Future<String?> pickTime(BuildContext c, String? initial) async {
  final p = (initial ?? '10:00').split(':');
  final tm = await showTimePicker(context: c, initialTime: TimeOfDay(hour: int.parse(p[0]), minute: int.parse(p[1])));
  return tm == null ? null : '${two(tm.hour)}:${two(tm.minute)}';
}

Future<bool> confirm(BuildContext c, String title, {String? ok}) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (d) => AlertDialog(
      title: Text(title, style: const TextStyle(fontSize: 17)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d, false), child: Text(t('नको', 'No'))),
        FilledButton(
            style: FilledButton.styleFrom(backgroundColor: C.red, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(d, true),
            child: Text(ok ?? t('हो, डिलीट', 'Yes, delete'))),
      ],
    ),
  );
  return r == true;
}

/// Asks "only this / this and all following" for repeating items. Returns null if cancelled.
Future<bool?> askScope(BuildContext c, String title) => showDialog<bool>(
      context: c,
      builder: (d) => SimpleDialog(title: Text(title, style: const TextStyle(fontSize: 17)), children: [
        SimpleDialogOption(onPressed: () => Navigator.pop(d, false), child: Padding(padding: const EdgeInsets.all(6), child: Text(t('फक्त हीच', 'Only this one')))),
        SimpleDialogOption(
            onPressed: () => Navigator.pop(d, true),
            child: Padding(padding: const EdgeInsets.all(6), child: Text(t('ही आणि पुढच्या सगळ्या', 'This and all following')))),
      ]),
    );

/// Delete with repeat awareness.
Future<bool> deleteItem(BuildContext c, Item e) async {
  final st = Store.I;
  final tp = e.parent != 0 ? st.byId(e.parent) : null;
  if (tp != null) {
    final all = await askScope(c, t('ही repeat नोंद डिलीट करायची?', 'Delete this repeating item?'));
    if (all == null) return false;
    if (all) {
      tp.repeatUntil = shiftKey(e.date, -1);
      st.items.removeWhere((x) => x.parent == tp.id && !x.done && x.date.compareTo(e.date) >= 0);
    } else {
      tp.skips.add(e.date);
      st.items.remove(e);
    }
    st.save();
    return true;
  }
  if (!await confirm(c, t('डिलीट करायचं?', 'Delete this?'))) return false;
  st.remove(e.id);
  return true;
}

class Section extends StatelessWidget {
  final String text;
  final Color? color;
  final Widget? trailing;
  const Section(this.text, {super.key, this.color, this.trailing});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 8),
        child: Row(children: [
          Expanded(child: Text(text, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: color ?? headColor(context)))),
          if (trailing != null) trailing!,
        ]),
      );
}

class Empty extends StatelessWidget {
  final String text;
  const Empty(this.text, {super.key});
  @override
  Widget build(BuildContext context) =>
      Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text(text, style: TextStyle(color: hint(context))));
}

class AiButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool busy;
  const AiButton(this.label, {super.key, this.onTap, this.busy = false});
  @override
  Widget build(BuildContext context) => Opacity(
        opacity: onTap == null || busy ? .6 : 1,
        child: Container(
          decoration: BoxDecoration(gradient: const LinearGradient(colors: [C.aiA, C.aiB]), borderRadius: BorderRadius.circular(22)),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(22),
              onTap: busy ? null : onTap,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Center(
                  child: busy
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                ),
              ),
            ),
          ),
        ),
      );
}

class ShareBar extends StatelessWidget {
  final String Function() text;
  final String subject;
  const ShareBar({super.key, required this.text, required this.subject});
  @override
  Widget build(BuildContext context) => Wrap(spacing: 8, runSpacing: 6, children: [
        ActionChip(avatar: const Text('📋'), label: Text(t('कॉपी', 'Copy')), onPressed: () => copyText(context, text())),
        ActionChip(avatar: const Text('📲'), label: const Text('WhatsApp'), onPressed: () => openUrl(context, 'https://wa.me/?text=${Uri.encodeComponent(text())}')),
        ActionChip(avatar: const Text('✉️'), label: const Text('Email'), onPressed: () => openEmail(context, subject, text())),
        ActionChip(avatar: const Text('↗️'), label: Text(t('शेअर', 'Share')), onPressed: () => Share.share(text())),
      ]);
}

class ResultBox extends StatelessWidget {
  final TextEditingController ctrl;
  final String subject;
  const ResultBox({super.key, required this.ctrl, required this.subject});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 10),
        TextField(controller: ctrl, maxLines: null, minLines: 4, decoration: InputDecoration(helperText: t('हवं तर edit करा', 'Edit if needed'))),
        const SizedBox(height: 6),
        ShareBar(text: () => ctrl.text, subject: subject),
      ]);
}

Future<void> reschedule(BuildContext c, Item e) async {
  final d = await pickDate(c, daysFrom(1));
  if (d == null || !c.mounted) return;
  final tm = await pickTime(c, e.time);
  e.date = d;
  if (tm != null) e.time = tm;
  Store.I.save();
  if (c.mounted) toast(c, t('🔁 ${nice(d)}${e.time != null ? ' ${e.time}' : ''} ला ढकललं', '🔁 Moved to ${nice(d)}${e.time != null ? ' ${e.time}' : ''}'));
}

void taskActions(BuildContext c, Item e) {
  showModalBottomSheet(
    context: c,
    showDragHandle: true,
    builder: (s) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(
            leading: const Icon(Icons.edit),
            title: Text(t('बदला (Edit)', 'Edit')),
            onTap: () {
              Navigator.pop(s);
              Navigator.push(c, MaterialPageRoute(builder: (_) => ItemFormPage(type: e.type, edit: e)));
            }),
        ListTile(
            leading: Icon(e.priority > 0 ? Icons.star : Icons.star_border, color: C.gold),
            title: Text(e.priority > 0 ? t('Priority काढा', 'Remove priority') : t('⭐ Priority द्या', '⭐ Mark priority')),
            onTap: () {
              e.priority = e.priority > 0 ? 0 : 1;
              Store.I.save(reschedule: false);
              Navigator.pop(s);
            }),
        ListTile(
            leading: const Icon(Icons.update),
            title: Text(t('🔁 पुढे ढकला', '🔁 Reschedule')),
            onTap: () {
              Navigator.pop(s);
              reschedule(c, e);
            }),
        ListTile(
            leading: Icon(Icons.delete_outline, color: redText(c)),
            title: Text(t('डिलीट', 'Delete'), style: TextStyle(color: redText(c))),
            onTap: () {
              Navigator.pop(s);
              deleteItem(c, e);
            }),
      ]),
    ),
  );
}

class ItemTile extends StatelessWidget {
  final Item e;
  final bool missed;
  final String? countdown;
  const ItemTile(this.e, {super.key, this.missed = false, this.countdown});

  @override
  Widget build(BuildContext context) {
    final h = hint(context);
    Color? bg;
    String icon = '';
    final rep = e.parent != 0 ? ' 🔁' : '';
    String meta = '${dayLabel(e.date)}${e.time != null ? ' · ⏰ ${e.time}' : ''}${e.person.isNotEmpty ? ' · 👤 ${e.person}' : ''}$rep';
    if (e.type == 'meeting') {
      bg = meetingBg(context);
      icon = '🤝';
      meta += ' · ${e.points.length} ${t('पॉइंट्स', 'points')}';
    } else if (e.type == 'trip') {
      bg = tripBg(context);
      icon = '✈️';
      meta = '${dayLabel(e.date)} · ${e.trip.where((i) => i.d).length}/${e.trip.length} ${t('बुकिंग पूर्ण', 'booked')}';
    }
    void open() {
      if (e.type == 'meeting') {
        Navigator.push(context, MaterialPageRoute(builder: (_) => MeetingPage(id: e.id)));
      } else if (e.type == 'trip') {
        Navigator.push(context, MaterialPageRoute(builder: (_) => TripPage(id: e.id)));
      } else {
        taskActions(context, e);
      }
    }

    void tick() {
      final st = Store.I;
      st.toggleDone(e);
      if (e.done) {
        toast(context, t('✔ झालं: ${e.title}', '✔ Done: ${e.title}'), action: t('↩ Undo', '↩ Undo'), onAction: () {
          e.done = false;
          st.justToggled.remove(e.id);
          st.save();
        });
      }
    }

    return Card(
      color: bg,
      shape: missed ? RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: redText(context))) : null,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: open,
        onLongPress: () => taskActions(context, e),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(6, 6, 12, 6),
          child: Row(children: [
            if (e.type == 'task')
              Checkbox(value: e.done, shape: const CircleBorder(), onChanged: (_) => tick())
            else
              Padding(padding: const EdgeInsets.symmetric(horizontal: 10), child: Text(icon, style: const TextStyle(fontSize: 22))),
            Expanded(
              child: AnimatedOpacity(
                duration: const Duration(milliseconds: 300),
                opacity: e.done ? .55 : 1,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    if (countdown != null) Text('⏳ $countdown', style: const TextStyle(color: C.gold, fontWeight: FontWeight.w700, fontSize: 12)),
                    Text(e.title + (e.priority > 0 ? '  ⭐' : ''),
                        style: TextStyle(fontSize: 15, decoration: e.done ? TextDecoration.lineThrough : null, color: e.done ? h : null)),
                    const SizedBox(height: 2),
                    Text(meta, style: TextStyle(fontSize: 12, color: h)),
                    if (missed)
                      Wrap(children: [
                        TextButton(onPressed: tick, child: Text(t('✔ झालं', '✔ Done'))),
                        TextButton(onPressed: () => reschedule(context, e), child: Text(t('🔁 पुढे ढकला', '🔁 Reschedule'))),
                      ]),
                  ]),
                ),
              ),
            ),
            if (e.type != 'task') Icon(Icons.chevron_right, color: h),
          ]),
        ),
      ),
    );
  }
}
